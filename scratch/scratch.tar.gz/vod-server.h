#ifndef VOD_SERVER_HH_
#define VOD_SERVER_HH_

#include "ns3/application.h"

#include <string>
#include <vector>

#include <unordered_map>
#include <list>

using namespace ns3;

struct serversData
{
	std::vector<bool> onOff;
	std::vector<double> memorySize;
	std::vector<double> memoryFree;
	std::vector< std::vector<uint16_t> > allocatedContentType;
	std::vector<Address> serverAddress;
	std::vector<double> cost;
};
serversData serverData;

void  serverInitialise (uint16_t serverId, double totalMemory, double freeMemory, std::vector<uint16_t> content, Address serverAddress, double cost)
{
	serverData.onOff.at(serverId) 				 = 0;
	serverData.memorySize.at(serverId) 			 = totalMemory;
	serverData.memoryFree.at(serverId) 			 = freeMemory;
	serverData.allocatedContentType.at(serverId) = content;
	serverData.serverAddress.at(serverId) 		 = serverAddress;
	serverData.cost.at(serverId) 				 = cost;
}

void setOn (uint16_t serverId)
{
	serverData.onOff.at(serverId) = 1;
}

void setOff (uint16_t serverId)
{
	serverData.onOff.at(serverId) = 0;
}

void allocateMemory(uint16_t serverId,double size)
{
	double freeMem = serverData.memoryFree.at(serverId);
	serverData.memoryFree.at(serverId) = freeMem - size;
}

void desallocateMemory(uint16_t serverId,double size)
{
	double freeMem=serverData.memoryFree.at(serverId);
	serverData.memoryFree.at(serverId) = freeMem + size;
}

void addContent (uint16_t serverId,uint16_t content,double size)
{
	allocateMemory(serverId,size);
	serverData.allocatedContentType.at(serverId).push_back(content);
//	saveToLogFiles();
}

void removeContent(uint16_t serverId,uint16_t content,double size)
{
	desallocateMemory(serverId,size);
	auto it = std::find(serverData.allocatedContentType.at(serverId).begin(), serverData.allocatedContentType.at(serverId).end(), content);
	int index=distance(serverData.allocatedContentType.at(serverId).begin(), it);
	serverData.allocatedContentType.at(serverId).erase(serverData.allocatedContentType.at(serverId).begin()+index);
	setOff(serverId);
//	saveToLogFiles ();
}

void printInformation (uint16_t serverId)
{
	std::cout << "ServerId:  " << serverId << std::endl;
	std::cout << "Total Memory:  " << serverData.memorySize.at(serverId) << std::endl;
	std::cout << "Free Memory:  " << serverData.memoryFree.at(serverId) << std::endl;
	std::cout << "Server Address:  " << Ipv4Address::ConvertFrom(serverData.serverAddress.at(serverId))<< std::endl;
	std::cout << "Content Id Allocated:" << ' ';
	for(uint16_t i = 0; i < serverData.allocatedContentType.at(serverId).size(); ++i)
	{
		std::cout << serverData.allocatedContentType.at(serverId)[i] << ' ';
		if (i == serverData.allocatedContentType.at(serverId).size()-1)
		{
			std::cout << ' ' << std::endl;
		}
	}
}

#endif // VOD_SERVER_HH_
