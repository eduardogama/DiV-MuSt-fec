#ifndef VOD_CONTROLLER_HH_
#define VOD_CONTROLLER_HH_

#include "ns3/application.h"

#include <string>
#include <vector>

#include <unordered_map>
#include <list>


#include "dash-utils.h"
#include "vod-utils.h"


#include "tree-utils.h"
#include "graph-utils.h"




enum BitRate 
{	
	//360p = 750,
	//540p = 1750,
	HD = 3000,
	FullHD = 5800,
	QuadHD = 9000,
	UHD = 20000
}; // Video BitRate em kbps 

template<typename T>
void pop_front(std::vector<T>& vec)
{
    assert(!vec.empty());
    vec.front() = std::move(vec.back());
    vec.pop_back();
}

static std::string Ipv4AddressToString (Ipv4Address ad)
{
	std::ostringstream oss;
	ad.Print (oss);
	return oss.str ();
}

vector<int> FindCommonGroups (vector<GroupUser *> &groups, vector<int> &free_groups, pair<string, ClusterNode> &server)
{
	vector<int> g_i;
	ClusterNode &candidate = server.second;
	
	cout << "[FindCommonGroups] " << server.first << " SIZE = " << candidate.str_groups.size() << endl;
	 
	for (unsigned i = 0; i < groups.size(); i++) {
		if(!free_groups[i])
			continue;
		for(unsigned j = 0; j < candidate.str_groups.size(); j++){
			if (groups[i]->getId() == candidate.str_groups[j]) {
				g_i.push_back(i);
			}
		}
	}
	
	cout << "[FindCommonGroups] Two SIZE = " << candidate.str_groups.size() << endl;

	return g_i;
}

vector<string> GroupUsers()
{
	vector<GroupUser *> &groups = NetworkSingleton::getInstance()->getGroups();
	vector<string> g;
	
	for(auto& g_1 : groups) {
		g.push_back(g_1->getServerIp());
	}
	
	return g;
}

string AddUserInGroup (unsigned int userId, int cont, int src, int dest)
{
	vector<GroupUser *> &groups = NetworkSingleton::getInstance()->getGroups();
	NodeContainer *clients = NetworkSingleton::getInstance()->getClients();
	Graph *graph = NetworkSingleton::getInstance()->getGraph();
	
	graph->dijkstra(dest, src);
	
	stringstream gstream;
	string server_ip  = NetworkSingleton::getInstance()->srv_ip;

    Ptr<Node> n = clients->Get(userId);
    Ptr<Ipv4> ipv4src = n->GetObject<Ipv4>();    
    gstream << ipv4src->GetAddress(1,0).GetLocal();
    
	cout << "==========================================================================\n";
	cout << "SERVER CDN " << server_ip << " CAPACITY " 
		 << setprecision (numeric_limits<double>::digits10 + 1) 
		 << cluster[server_ip].target_capacity << endl;
    cout << "Starting Application client (" << userId << ") " << gstream.str() << " "; 
    
	cout << "USER ID = " << userId << " USER IP = " << gstream.str() << " BROAD = " 
		 << ipv4src->GetAddress(1, 0).GetBroadcast() << endl;
    
    EndUser *new_user = new EndUser();
    new_user->setId(userId);
    new_user->setIp(gstream.str());
	new_user->setContent(cont);

    gstream.str(""); gstream << ipv4src->GetAddress(1, 0).GetBroadcast(); //gstream Broadcast Id

    if (groups.empty()) {
    	GroupUser *new_group = new GroupUser();

		new_group->setId(gstream.str());
		new_group->addUser(new_user);
		new_group->addAddress(ipv4src->GetAddress(1, 0).GetBroadcast());
		new_group->setContent(cont);
		new_group->setIpv4(ipv4src);
		new_group->setSrc(src);
		new_group->setDst(dest);
		new_group->setServerIp(server_ip);
		
		new_group->route = graph->route;
		new_group->current = 0;
		
		groups.push_back(new_group);
		
		for (unsigned p_i = 0; p_i < graph->route.size() - 1; p_i++) {
    	
			int j   = graph->route[p_i];
			int j_1 = graph->route[p_i + 1];
	
			for (auto& pair : cluster) {
				auto& key_pair = pair.second;
		
				if (j == key_pair.getSrcId() && j_1 == key_pair.getDstId()) { // find Output Interface 
					cluster[pair.first].str_groups.push_back(gstream.str());
					break;
				}
			}
		}
		
		cluster[server_ip].target_capacity -= 5800000;
		
    	return server_ip;
    }

    vector<string> str_addr = split(gstream.str(), ".");
    
    bool insert_group = false;
    for (auto& group : groups) {
	    vector<string> group_addr = split(group->getId(), ".");
		
		bool same_group = true;
		for (unsigned i = 0; i < str_addr.size()-1; i++) {
			if (group_addr[i] != str_addr[i]) {
				same_group = false;
				break;
			}
		}
		
		if (same_group /*and cont == it->getContent()*/) {
	    	group->addUser(new_user);
	    	insert_group = true;
			
			server_ip = group->getServerIp();
			break;
		}
    }
    
    if (!insert_group) {
		GroupUser *new_group = new GroupUser();
		
		new_group->setId(gstream.str());
		new_group->addUser(new_user);
		new_group->addAddress(ipv4src->GetAddress(1, 0).GetBroadcast());
		new_group->setContent(cont);
		new_group->setIpv4(ipv4src);
		new_group->setSrc(src);
		new_group->setDst(dest);
		new_group->setServerIp(server_ip);
		
		new_group->route = graph->route;
		new_group->current = 0;
		
		groups.push_back(new_group);
		
		for (unsigned p_i = 0; p_i < graph->route.size() - 1; p_i++) {
    	
			int j   = graph->route[p_i];
			int j_1 = graph->route[p_i + 1];
	
			for (auto& pair : cluster) {
				auto& key_pair = pair.second;
		
				if (j == key_pair.getSrcId() && j_1 == key_pair.getDstId()) { // find Output Interface 
					cluster[pair.first].str_groups.push_back(gstream.str());
					break;
				}
			}
		}
	
    }
    
    cluster[server_ip].target_capacity -= 5800000;
    
    return server_ip;
}

void ResetCapacityLink (string &server_ip)
{
	cluster[server_ip].target_capacity = cluster[server_ip].capacity;
}

bool calcCapacity (vector<int> &g_i, string &server_ip)
{
	vector<GroupUser *> &groups = NetworkSingleton::getInstance()->getGroups();
	
	for (auto const& i : g_i) {
		cluster[server_ip].target_capacity -= 5800000 * groups[i]->getUsers().size();	
	}
	
	if (cluster[server_ip].getTargetCapacity() > 0) {
		return true;
	} else {
		return false;
	}
}

pair<string, ClusterNode> FindServer (GroupUser *group, unsigned current)
{
	if (current > group->route.size() - 1) {
		cout << "CASA CAIU !!! ========================\n";
//		getchar();
	}
	int j   = group->route[current];
	int j_1 = group->route[current + 1];
	
	for (auto const& pair : cluster) {
		auto key_pair = pair.second;
		
		if (j == key_pair.getSrcId() && j_1 == key_pair.getDstId()) { // find Output Interface 
			return pair;
		}
	}
}

void ISOA (vector<int> &free_groups, int current)
{
	vector<GroupUser *> &groups = NetworkSingleton::getInstance()->getGroups();

	for (unsigned k = 0; k < free_groups.size(); k++) {
		if (!free_groups[k])
				continue;
				
		if (current == groups[k]->route.size()) {
			pair<string, ClusterNode> candidate_node = FindServer(groups[k], current);
		
			groups[k]->current = current;
			groups[k]->setServerIp(candidate_node.first);

			free_groups[k] = 0;
		}
	}
	
	for (unsigned i = 0; i < free_groups.size(); i++) {
		
		if (!free_groups[i])
			continue;
		
		pair<string, ClusterNode> candidate_node = FindServer(groups[i], current);
		
		vector<int> g_i = FindCommonGroups(groups, free_groups, candidate_node);
		
		if (g_i.size() > 0 & calcCapacity(g_i, candidate_node.first)) { //set server in free_groups
			for (unsigned k = 0; k < g_i.size(); k++) {
				groups[g_i[k]]->current = current;
				groups[g_i[k]]->setServerIp(candidate_node.first);

				free_groups[g_i[k]] = 0;
			}
		} else {
			
			current++;
			ISOA(g_i, current);
		}
	}
}

void SetupRequestRoutingEntry (unsigned int userId, int cont, int src, int dest)
{
	AddUserInGroup(userId, cont, src, dest);
	
	vector<GroupUser *> &groups = NetworkSingleton::getInstance()->getGroups();
	string server_ip = NetworkSingleton::getInstance()->srv_ip;
	if (cluster[server_ip].getTargetCapacity() <= 0) {
		cout << "[SetupRequestRoutingEntry] NODE TARGET CAPACITY VIOLATED : " << cluster[server_ip].getTargetCapacity() << endl;
	
		int current = 0;
		vector<int> free_groups(groups.size(), 1);

		ResetCapacityLink(server_ip);
		ISOA(free_groups, current);
		
		for (auto& pair : cluster)
			pair.second.target_capacity = pair.second.capacity;
		
		for (auto& group : groups)
			cluster[group->getServerIp()].target_capacity -= group->getUsers().size() * 5800000;
		
		NetworkSingleton::getInstance()->DoSendRedirect = true;
	}
}

void SetupRemoveRoutingEntry(string routesFile, unsigned int i, NodeContainer &clients)
{
	vector<GroupUser *> &groups = NetworkSingleton::getInstance()->getGroups();
	
	stringstream gstream;

    Ptr<Node> n = clients.Get(i);
    Ptr<Ipv4> ipv4 = n->GetObject<Ipv4>();    
    gstream << ipv4->GetAddress(1,0).GetLocal();
    
	vector<string> addr = split(gstream.str(), ".");

	for (auto& it : groups) {
		vector<string> group_addr = split(it->getId(), ".");
		
		bool same_group = true;
		for (unsigned int j = 0; j < addr.size()-1; j++) {
			if (group_addr[j] != addr[j]) {
				same_group = false;
				break;
			}
		}
		
		if (same_group) {
			vector<EndUser *> users = it->getUsers();
			
			for (vector<EndUser *>::iterator it = users.begin(); it != users.end(); ++it) { //Error 2-4
				if ((*it)->getIp() == gstream.str()) {
					users.erase(it);
					break;
				}
			}
			break;
		}
	}
}

void printGroups()
{
	vector<GroupUser *> &groups = NetworkSingleton::getInstance()->getGroups();
	for (auto &group : groups) {
		std::cout << "GROUP IP " << group->getId() << " CONTENT " << group->getContent() << std::endl;
		for (auto &user : group->getUsers()) {
			cout << "-> User(" << user->getId() << ") : " << user->getIp() << " Server(" << group->route[group->current] << ") : "<< group->getServerIp() << endl;
		}
	}
}

#endif // VOD_CONTROLLER_HH_
