/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2011 Centre Tecnologic de Telecomunicacions de Catalunya (CTTC)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Jaume Nin <jaume.nin@cttc.cat>
 */

#include "ns3/lte-helper.h"
#include "ns3/epc-helper.h"
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/ipv4-global-routing-helper.h"
#include "ns3/internet-module.h"
#include "ns3/mobility-module.h"
#include "ns3/lte-module.h"
#include "ns3/applications-module.h"
#include "ns3/point-to-point-helper.h"
#include "ns3/config-store.h"
//#include "ns3/gtk-config-store.h"

#include "ns3/random-variable-stream.h"
#include "ns3/rng-seed-manager.h"

#include "ns3/dashplayer-tracer.h"

#include <fstream>
#include <string>
#include <sstream>
#include <vector>

using namespace ns3;

/**
 * Sample simulation script for LTE+EPC. It instantiates several eNodeB,
 * attaches one UE per eNodeB starts a flow for each UE to and from a remote host.
 * It also  starts yet another flow between each UE pair.
 */

NS_LOG_COMPONENT_DEFINE ("EpcDashExample");


int main (int argc, char* argv[])
{
    uint16_t numberOfNodes = 2;
    double simTime         = 100;
    double dist            = 60.0;
    
    string AdaptationLogicToUse = "dash::player::RateAndBufferBasedAdaptationLogic";
    
    CommandLine cmd;
    
    cmd.AddValue("NumberOfNodes", "Number of eNodesBs + UE pairs", numberOfNodes);
    cmd.AddValue("simTime", "Total Duration of the simulation [s]", simTime);
    cmd.AddValue("distance", "Distance between eNBs [m]", dist);
    cmd.AddValue("AdaptationLogicToUse", "Adaptation Logic to Use.", AdaptationLogicToUse);
    
    Ptr<LteHelper> lteHelper = CreateObject<LteHelper>();
    Ptr<PointToPointEpcHelper> epcHelper = CreateObject<PointToPointEpcHelper>();
    lteHelper->SetEpcHelper(epcHelper);
    
    ConfigStore inputConfig;
    inputConfig.ConfigureDefaults();
    
    // parse again so you can override default values from the command line
    cmd.Parse(argc, argv);

    Ptr<Node> pgw = epcHelper->GetPgwNode ();

    // Create a single RemoteHost
    NodeContainer remoteHostContainer;
    remoteHostContainer.Create(1);
    Ptr<Node> remoteHost = remoteHostContainer.Get(0);
    InternetStackHelper internet;
    internet.Install(remoteHostContainer);
    
    // Create the Internet
    PointToPointHelper p2p;
    p2p.SetDeviceAttribute ("DataRate", DataRateValue (DataRate ("10Mbps")));
    p2p.SetDeviceAttribute ("Mtu", UintegerValue (1500));
    
    NetDeviceContainer internetDevices = p2p.Install(pgw, remoteHost);
    Ipv4AddressHelper ipv4;
    ipv4.SetBase("1.0.0.0", "255.0.0.0");
    Ipv4InterfaceContainer internetIpIfaces = ipv4.Assign(internetDevices);
    // interface 0 is localhost, 1 is the p2p device
//    Ipv4Address remoteHostAddr = internetIpIfaces.GetAddress (1);
    
    Ipv4StaticRoutingHelper ipv4RoutingHelper;
    Ptr<Ipv4StaticRouting> remoteHostStaticRouting = ipv4RoutingHelper.GetStaticRouting(remoteHost->GetObject<Ipv4> ());
    remoteHostStaticRouting->AddNetworkRouteTo(Ipv4Address ("7.0.0.0"), Ipv4Mask ("255.0.0.0"), 1);      
    
    // --------------------------------------------------------------------------------------------
    NodeContainer ueNodes;
    NodeContainer enbNodes;
    enbNodes.Create(numberOfNodes);
    ueNodes.Create(numberOfNodes);
    
    // Install Mobility Model
    Ptr<ListPositionAllocator> positionAlloc = CreateObject<ListPositionAllocator> ();
    for (uint16_t i = 0; i < numberOfNodes; i++)
    {
        positionAlloc->Add(Vector(dist * i, 0, 0));
    }
    MobilityHelper mobility;
    mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
    mobility.SetPositionAllocator(positionAlloc);
    mobility.Install(enbNodes);
    mobility.Install(ueNodes);
    
    // Install LTE Devices to the nodes
    NetDeviceContainer enbLteDevs = lteHelper->InstallEnbDevice (enbNodes);
    NetDeviceContainer ueLteDevs = lteHelper->InstallUeDevice (ueNodes);
    
    // Install the IP stack on the UEs
    internet.Install(ueNodes);
    Ipv4InterfaceContainer ueIpIface;
    ueIpIface = epcHelper->AssignUeIpv4Address(NetDeviceContainer(ueLteDevs));
    // Assign IP address to UEs, and install applications
    for (uint32_t u = 0; u < ueNodes.GetN(); u += 1)
    {
        Ptr<Node> ueNode = ueNodes.Get (u);
        // Set the default gateway for the UE
        Ptr<Ipv4StaticRouting> ueStaticRouting = ipv4RoutingHelper.GetStaticRouting (ueNode->GetObject<Ipv4> ());
        ueStaticRouting->SetDefaultRoute (epcHelper->GetUeDefaultGatewayAddress (), 1);
    }
    
    // Attach one UE per eNodeB
    for (uint16_t i = 0; i < numberOfNodes; i++)
    {
        lteHelper->Attach (ueLteDevs.Get(i), enbLteDevs.Get(i));
        // side effect: the default EPS bearer will be activated
    }
    
    
    // ---------- Create Dash Server Setup -------------------------------------------
    stringstream gstream; //gstream << 4; string g=gstream.str(); 

    Ptr<Ipv4> ipv4h = remoteHost->GetObject<Ipv4> ();    
    gstream << ipv4h->GetAddress(1,0).GetLocal();

    NS_LOG_INFO("Create Applications.");
    string srv_ip = gstream.str();
    gstream.str("");
    
    cout << "Ap Wifi Node --> " << srv_ip << '\n';
    string representationStrings = "/home/eduardo/dataset/netflix_vid1.csv";
    fprintf(stderr, "representations = %s\n", representationStrings.c_str ());

    DASHServerHelper server (Ipv4Address::GetAny (), 80,  srv_ip,
                           "/content/mpds/", representationStrings, "/content/segments/");

    ApplicationContainer serverApp;
    serverApp = server.Install(remoteHost);
    
    // ---------- End Create Dash Server Setup -------------------------------------------    
    
    
    // ---------- Network Seed Setup ------------------------------------------------
    SeedManager::SetRun(time(0));
    Ptr<UniformRandomVariable> uv = CreateObject<UniformRandomVariable> ();    
    // ---------- End Network Seed Setup --------------------------------------------

    double rdm = 0.0;
    
    ApplicationContainer clientApps;
    for (uint32_t u = 0; u < ueNodes.GetN(); u += 1)
    {
        stringstream mpd_baseurl;

        mpd_baseurl << "http://" << srv_ip << "/content/mpds/";

        int videoId = 0;
        int screenWidth = 1920, screenHeight = 1080;

        stringstream ssMPDURL;
        ssMPDURL << mpd_baseurl.str () << "vid" << videoId+1 << ".mpd.gz";

        DASHHttpClientHelper player(ssMPDURL.str ());
        player.SetAttribute("AdaptationLogic", StringValue(AdaptationLogicToUse));
        player.SetAttribute("StartUpDelay", StringValue("4"));
        player.SetAttribute("ScreenWidth", UintegerValue(screenWidth));
        player.SetAttribute("ScreenHeight", UintegerValue(screenHeight));
        player.SetAttribute("UserId", UintegerValue(u));
        player.SetAttribute("AllowDownscale", BooleanValue(true));
        player.SetAttribute("AllowUpscale", BooleanValue(true));
        player.SetAttribute("MaxBufferedSeconds", StringValue("60"));
        
        ApplicationContainer clientApp = player.Install(ueNodes.Get(u));
        clientApp.Start(Seconds(0.25 + rdm));
        clientApp.Stop(Seconds(simTime));

        clientApps.Add(clientApp);
    }
    

    AsciiTraceHelper ascii;
    p2p.EnableAsciiAll (ascii.CreateFileStream ("myfirst.tr"));
    p2p.EnablePcapAll ("myfirst");


    Simulator::Stop(Seconds(simTime));
    Simulator::Run();

    /*GtkConfigStore config;
    config.ConfigureAttributes();*/

    Simulator::Destroy();
    
    
    return 0;
}

