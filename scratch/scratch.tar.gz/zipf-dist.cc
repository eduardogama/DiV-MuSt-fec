#include "ns3/core-module.h"


using namespace ns3;

NS_LOG_COMPONENT_DEFINE ("ZipfDist");

int main(int argc, char *argv[])
{
	NS_LOG_UNCOND ("Zipf Distribution");

	
	uint32_t n = 100;
	double alpha = 2.0;
	Ptr<ZipfRandomVariable> x = CreateObject<ZipfRandomVariable> ();
	x->SetAttribute ("N", IntegerValue (n));
	x->SetAttribute ("Alpha", DoubleValue (alpha));
	// The expected value for the mean of the values returned by a
	// Zipfly distributed random variable is equal to
	//
	//                   H
	//                    N, alpha - 1
	//     E[value]  =  ---------------
	//                     H
	//                      N, alpha
	//
	// where
	//
	//                    N
	//                   ---
	//                   \     -alpha
	//     H          =  /    m        .
	//      N, alpha     ---
	//                   m=1
	//
	// For this test,
	//
	//                      -(alpha - 1)
	//                     1
	//     E[value]  =  ---------------
	//                      -alpha
	//                     1
	//
	//               =  1  .
	//
	double value = x->GetValue ();

	printf("%f\n", value);
	
	Simulator::Run ();
	Simulator::Destroy ();
}
