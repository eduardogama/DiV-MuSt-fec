/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/**
 * Copyright (c) 2015 Christian Kreuzberger and Daniel Posch, Alpen-Adria-University 
 * Klagenfurt
 *
 * This file is part of amus-ndnSIM, based on ndnSIM. See AUTHORS for complete list of 
 * authors and contributors.
 *
 * amus-ndnSIM and ndnSIM are free software: you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License as published by the Free Software 
 * Foundation, either version 3 of the License, or (at your option) any later version.
 *
 * amus-ndnSIM is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 * PURPOSE.  See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * amus-ndnSIM, e.g., in COPYING.md file.  If not, see <http://www.gnu.org/licenses/>.
 **/

#include "ns3/core-module.h"
#include "ns3/csma-module.h"
#include "ns3/internet-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/ndnSIM-module.h"
#include "ns3/ndnSIM/apps/ndn-app.hpp"

#include "ns3/applications-module.h"

#include "ns3/mobility-module.h"
#include "ns3/yans-wifi-helper.h"
#include "ns3/ssid.h"

#include "ns3/flow-monitor-module.h"
#include "ns3/random-variable-stream.h"
#include "ns3/rng-seed-manager.h"

#include "ns3/netanim-module.h"


extern vector<vector<int> > readNxNMatrix (std::string adj_mat_file_name);
extern vector<vector<double> > readCordinatesFile (std::string node_coordinates_file_name);
extern void printCoordinateArray (const char* description, vector<vector<double> > coord_array);
extern void printMatrix (const char* description, vector<vector<int> > array);

extern vector<std::string> split(const std::string& str, const std::string& delim);
extern void store(uint32_t &tNodes, uint32_t &layer, uint32_t &users, uint16_t &seed, std::string &str);
extern void calcAvg(uint32_t &tNodes, uint32_t &layer, uint32_t &users);

NS_LOG_COMPONENT_DEFINE("NdnDashExample");



uint32_t tRate;
double tStalls;
double tStalls_time;

std::string dir;

class Experiment {
    public:
        Experiment();
        ~Experiment();
        
        bool CreateDir(string name);
        string getDirectory();
        void setDirectory();
    private:
        string dir;
};

Experiment::Experiment(){
}

Experiment::~Experiment(){
}

bool Experiment::CreateDir(string name) {
    dir = name;
    return system(string(string("mkdir -p ") + name).c_str()) != -1;
}

string Experiment::getDirectory(){
    return dir;
}

void setDirectory(string _dir){
    dir = _dir;
}


namespace ns3 {


int
main(int argc, char* argv[])
{
    uint16_t seed = 0;

    tStalls      = 0;
    tStalls_time = 0;
    tRate        = 0;
    
    bool tracing     = false;
    uint32_t n_nodes = 5;
    uint32_t users   = 1;
    uint32_t layer   = 0;
    double stopTime  = 100.0;
    string window    = "10s";
    string has       = "ns3::dash::RateAndBufferBasedAdaptationLogic";

    LogComponentEnable ("NdnDashExample", LOG_LEVEL_ALL);



    // Read optional command-line parameters (e.g., enable visualizer with ./waf --run=<> --visualize
    CommandLine cmd;
    cmd.AddValue("tracing", "Flag to enable/disable tracing", tracing);
    cmd.AddValue("users", "The number of concurrent videos", users);
    cmd.AddValue("nodes", "The number of nodes.", n_nodes);
    cmd.AddValue("layer", "The layer where the nodes support the cloud provisioning resquest segments clients", layer);
    cmd.AddValue("stopTime", "The time when the clients will stop requesting segments", stopTime);
    cmd.AddValue("seed", "Seed experiment.", seed);
    cmd.AddValue("protocol", "Seed experiment.", has);
    
    cmd.Parse(argc, argv);

    Config::SetDefault("ns3::TcpSocket::SegmentSize", UintegerValue(1400));
    Config::SetDefault("ns3::TcpSocket::DelAckCount", UintegerValue(0));
//    Config::SetDefault("ns3::DropTailQueue::Mode", StringValue("QUEUE_MODE_PACKETS"));
//    Config::SetDefault("ns3::DropTailQueue::MaxSize", StringValue ("50p"));    


    std::string adj_mat_file_name ("scratch/adjacency_matrix_5_nodes_v2.txt");
    
    
    
    // ---------- Read Adjacency Matrix ----------------------------------------
    vector<vector<int> > Adj_Matrix;
    Adj_Matrix = readNxNMatrix (adj_mat_file_name);

    printMatrix ("Initial network", Adj_Matrix);
    // ---------- End of Read Adjacency Matrix ---------------------------------
    
    // ---------- Network Setup ------------------------------------------------
    NS_LOG_INFO("Create nodes."); // Explicitly create the nodes required by the topology (shown above).

    NodeContainer nodes;   // Declare nodes objects
    nodes.Create (n_nodes);

    NS_LOG_INFO("Create channels.");

    // Explicitly create the point-to-point link required by the topology (shown above).
    PointToPointHelper p2p;

    NS_LOG_INFO ("Create Links Between Nodes.");

    vector<NetDeviceContainer> devices;

    stringstream gstream; //gstream << 4; std::string g=gstream.str();
    for (size_t i = 0; i < Adj_Matrix.size (); i++) {
        for (size_t j = 0; j < Adj_Matrix[i].size (); j++) {
            if (Adj_Matrix[i][j] != 0) {
                NodeContainer n_links = NodeContainer (nodes.Get (i), nodes.Get (j));

                // Check this later. Sum among string 
//                string l = std::to_string(Adj_Matrix[i][j]) + std::string("Mbps");
                
                gstream << Adj_Matrix[i][j] << "Mbps";
                p2p.SetDeviceAttribute("DataRate", StringValue(gstream.str()));
                // p2p.SetChannelAttribute("Delay", StringValue("50ms"));

                NetDeviceContainer n_devs = p2p.Install (n_links);

                devices.push_back(n_devs);
                NS_LOG_INFO ("matrix element [" << i << "][" << j << "] is 1");
                gstream.str("");
            }
        }
    }
    NS_LOG_INFO ("Number of all nodes is: " << nodes.GetN());
    // ---------- End Network Setup ------------------------------------------------
    
    
    // ---------- Network WiFi Users Setup -------------------------------------
    NodeContainer wifiStaNodes;
    wifiStaNodes.Create(users);

    // AP node to connect host the users 
    NodeContainer wifiApNode = nodes.Get(4);

    YansWifiChannelHelper channel = YansWifiChannelHelper::Default();
    YansWifiPhyHelper phy = YansWifiPhyHelper::Default();
    phy.SetChannel(channel.Create());

    WifiHelper wifi;
    wifi.SetRemoteStationManager("ns3::AarfWifiManager");

    WifiMacHelper mac;
    Ssid ssid = Ssid("ns-3-ssid");
    mac.SetType ("ns3::StaWifiMac",
                 "Ssid", SsidValue (ssid),
                 "ActiveProbing", BooleanValue (false));

    NetDeviceContainer staDevices;
    staDevices = wifi.Install(phy, mac, wifiStaNodes);

    mac.SetType("ns3::ApWifiMac", "Ssid", SsidValue(ssid));

    NetDeviceContainer apDevices;
    apDevices = wifi.Install(phy, mac, wifiApNode);

    MobilityHelper mobility;
    Ptr<ListPositionAllocator> positionAlloc = CreateObject <ListPositionAllocator>();

    // Initialize the coordinates and allocate the coordinates in each network node
    int aux = 360/(users/2);
    int dist = 8;
    
    for (size_t i = 0; i < 360; i += aux) {
        double cosseno = cos(i);
        double seno    = sin(i);
        positionAlloc->Add(Vector(dist*cosseno, dist*seno, 0)); // node1 -- starting very far away

        cout << "(x - y) = " << dist*cosseno << " - " << dist*seno << '\n';
    }

    for (size_t i = 0; i < 360; i += aux) {
        double cosseno = cos(i);
        double seno    = sin(i);
        positionAlloc->Add(Vector(dist*cosseno + 30, dist*seno, 0)); // node1 -- starting very far away

        cout << "(x - y) = " << dist*cosseno << " - " << dist*seno << '\n';
    }

    positionAlloc->Add(Vector(19, 15, 0)); // node0
    positionAlloc->Add(Vector(17, 15, 0)); // node0
    positionAlloc->Add(Vector(15, 15, 0)); // node0
    positionAlloc->Add(Vector(30, 0, 0)); // node0
    positionAlloc->Add(Vector(0, 0, 0));   // node0

    mobility.SetPositionAllocator(positionAlloc);

    mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");

    mobility.Install(wifiStaNodes);

    mobility.Install(nodes.Get(0));
    mobility.Install(nodes.Get(1));
    mobility.Install(nodes.Get(2));
    mobility.Install(nodes.Get(3));
    mobility.Install(nodes.Get(4));
    // ---------- End Network WiFi Users Setup ---------------------------------


    // ---------- Internet Stack Setup -------------------------------------------
    NS_LOG_INFO ("Install Internet Stack to Nodes.");

    InternetStackHelper internet;
    internet.Install(NodeContainer::GetGlobal());

    NS_LOG_INFO ("Assign Addresses to Nodes.");

    Ipv4AddressHelper ipv4_n;
    ipv4_n.SetBase("10.1.1.0", "255.255.255.0");

    for (size_t i = 0; i < devices.size(); i++) {
        ipv4_n.Assign(devices[i]);
        ipv4_n.NewNetwork();
    }

    for (size_t i = 0; i < n_nodes; i++) {
        Ptr<Node> n = nodes.Get(i);
        Ptr<Ipv4> ipv4 = n->GetObject<Ipv4> ();
        cout << "Node " << i << " --> " << ipv4->GetAddress(1,0) << '\n';
    }

    ipv4_n.Assign(staDevices);
    ipv4_n.Assign(apDevices);

    for (size_t i = 0; i < users; i++) {
        Ptr<Node> n = wifiStaNodes.Get(i);
        Ptr<Ipv4> ipv4 = n->GetObject<Ipv4> ();
        cout << "WiFi User Node " << i << " --> " << ipv4->GetAddress(1,0) << '\n';
    }
    
    vector<Ipv4Address> ipv4_interfaces;
    vector<string> ipNodes;
    
    for (size_t i = 0; i < n_nodes; i++) {
        Ptr<Node> fog_n = nodes.Get(i);
        Ptr<Ipv4> fog_ipv4 = fog_n->GetObject<Ipv4> ();
        Ipv4InterfaceAddress fog_ipv4_int_addr = fog_ipv4->GetAddress (1, 0);

        ipv4_interfaces.push_back(fog_ipv4_int_addr.GetLocal());
        
        gstream << fog_ipv4_int_addr.GetLocal();
        
        ipNodes.push_back(gstream.str());
        gstream.str("");
    }    
    // ---------- End Internet Stack Setup -------------------------------------------
    
    
    // ---------- Create Dash Server Setup -------------------------------------------
    NS_LOG_INFO("Create Applications.");
    string srv_ip = ipNodes[3];
    string fog_ip = ipNodes[4];


    // Install NDN stack on all nodes
    ndn::StackHelper ndnHelper;
    ndnHelper.SetDefaultRoutes(true);
    ndnHelper.setCsSize(0);
    ndnHelper.SetOldContentStore("ns3::ndn::cs::Lru", "MaxSize", "100");
    ndnHelper.InstallAll();

    // Choosing forwarding strategy
    ndn::StrategyChoiceHelper::InstallAll("/myprefix", "/localhost/nfd/strategy/best-route");


    string representationStrings = "netflix_vid1.csv";
    fprintf(stderr, "representations = %s\n", representationStrings.c_str ());

    
    // ------------ CLOUD NODE ----------------
    ndn::AppHelper fakeDASHProducerHelper("ns3::ndn::FakeMultimediaServer");

    // This fake multimedia producer will reply to all requests starting with /myprefix/FakeVid1
    fakeDASHProducerHelper.SetPrefix("/myprefix/FakeVid1");
    fakeDASHProducerHelper.SetAttribute("MetaDataFile", StringValue("/home/eduardo/dataset/netflix_vid1.csv"));
    // We just give the MPD file a name that makes it unique
    fakeDASHProducerHelper.SetAttribute("MPDFileName", StringValue("vid1.mpd"));

    ApplicationContainer serverApp;
    serverApp = fakeDASHProducerHelper.Install(nodes.Get(1));
    serverApp.Start(Seconds(0.0));
    serverApp.Stop(Seconds(stopTime));
    
    // ------------ FOG NODE ----------------
//    ndn::AppHelper fog_fakeDASHProducerHelper("ns3::ndn::FakeMultimediaServer");

//    // This fake multimedia producer will reply to all requests starting with /myprefix/FakeVid1
//    fog_fakeDASHProducerHelper.SetPrefix("/myprefix/FakeVid1");
//    fog_fakeDASHProducerHelper.SetAttribute("MetaDataFile", StringValue("/home/eduardo/dataset/netflix_vid1.csv"));
//    // We just give the MPD file a name that makes it unique
//    fog_fakeDASHProducerHelper.SetAttribute("MPDFileName", StringValue("vid1.mpd"));

//    ApplicationContainer fogServerApp;
//    fogServerApp = fog_fakeDASHProducerHelper.Install(nodes.Get(0));
//    fogServerApp.Start(Seconds(0.0));
//    fogServerApp.Stop(Seconds(stopTime));
    // ---------- End Create Dash Server Setup ------------------------------------------    


    // ---------- Network Seed Setup ------------------------------------------------
    SeedManager::SetRun(time(0));
    Ptr<UniformRandomVariable> uv = CreateObject<UniformRandomVariable> ();
    // ---------- End Network Seed Setup --------------------------------------------

    // ---------- Create Dash client Setup -------------------------------------------

    double rdm = 0.0;

    for (uint32_t user = 0; user < users; user++) {

        int screenWidth = 1920;
        int screenHeight = 1080;
                        
        ns3::ndn::AppHelper consumerHelper("ns3::ndn::FileConsumerCbr::MultimediaConsumer");
        consumerHelper.SetAttribute("AllowUpscale", BooleanValue(true));
        consumerHelper.SetAttribute("AllowDownscale", BooleanValue(true));
        consumerHelper.SetAttribute("ScreenWidth", UintegerValue(screenWidth));
        consumerHelper.SetAttribute("ScreenHeight", UintegerValue(screenHeight));
        consumerHelper.SetAttribute("StartRepresentationId", StringValue("auto"));
        consumerHelper.SetAttribute("MaxBufferedSeconds", UintegerValue(1600));
        consumerHelper.SetAttribute("StartUpDelay", StringValue("0.5"));

        consumerHelper.SetAttribute("AdaptationLogic", StringValue(has));
        consumerHelper.SetAttribute("MpdFileToRequest", StringValue(std::string("/myprefix/FakeVid1/vid1.mpd" )));

        rdm += uv->GetValue();
        
        //consumerHelper.SetPrefix (std::string("/Server_" + boost::lexical_cast<std::string>(i%server.size ()) + "/layer0"));
        
        ApplicationContainer app1 = consumerHelper.Install(wifiStaNodes.Get(user));
        app1.Start(Seconds(0.25 + rdm));
        app1.Stop(Seconds(stopTime));
    }
    // ---------- End Create Dash client Setup -------------------------------------------
    
    Experiment exp;
    
    gstream << "dash-1-zone-same-dist-" << n_nodes << "-" << users << "-" << layer;
    
    
    if (!exp.CreateDir(gstream.str())) {
        printf("Error creating directory!n");
        exit(1);
    }

    gstream.str("");
    
    
    // We can install more then one fake multimedia producer on one node:

    ndn::GlobalRoutingHelper ndnGlobalRoutingHelper;
    ndnGlobalRoutingHelper.InstallAll();

    ndnGlobalRoutingHelper.AddOrigins("/myprefix", nodes.Get(1));
    ndn::GlobalRoutingHelper::CalculateRoutes();

    Simulator::Stop(Seconds(stopTime));
    
    gstream << exp.getDirectory() << "/output-dash-" << seed << ".csv";
    ndn::DASHPlayerTracer::InstallAll(gstream.str());
    gstream.str("");


    AnimationInterface anim("topology.netanim");

    Simulator::Run();
    Simulator::Destroy();

    NS_LOG_UNCOND("Simulation Finished.");

    ndn::DASHPlayerTracer::Destroy();


    return 0;
}

} // namespace ns3

int
main(int argc, char* argv[])
{
    return ns3::main(argc, argv);
}


// ---------- Function Definitions -------------------------------------------

void calcAvg(uint32_t &tNodes, uint32_t &layer, uint32_t &users) {
    fstream file;

    ostringstream arq;   // stream used for the conversion

    arq << dir << "/" << "Bt_total_" << tNodes << "_" << users << "_" << layer << ".txt";

    file.open(arq.str().c_str(),fstream::out | fstream::app);


    locale mylocale("");
    file.imbue( mylocale );

    file << tStalls/(users) << " " << tStalls_time/(users) << " " << tRate/(users) << endl;

    file.close();
}

void store(uint32_t &tNodes, uint32_t &layer, uint32_t &users, uint16_t &seed, std::string &str) {
    fstream file;

    ostringstream arq;   // stream used for the conversion
    arq << dir << "/" << "Bt_PerUser_" << seed << "_" << tNodes << "_" << users << "_" << layer << ".txt";

    file.open(arq.str().c_str(),fstream::out | fstream::app);

    locale mylocale("");
    file.imbue( mylocale );

    //PB per user
    file << str << endl;
    file.close();

    vector<string> tokens = split(str, " ");
}

vector<std::string> split(const std::string& str, const std::string& delim) {
    std::vector<std::string> tokens;
    size_t prev = 0, pos = 0;
    do {
        pos = str.find(delim, prev);
        if (pos == string::npos) pos = str.length();
        string token = str.substr(prev, pos-prev);
        if (!token.empty()) tokens.push_back(token);
        prev = pos + delim.length();
    } while (pos < str.length() && prev < str.length());

    return tokens;
}

vector<vector<int> > readNxNMatrix (std::string adj_mat_file_name) {
    ifstream adj_mat_file;
    adj_mat_file.open (adj_mat_file_name.c_str (), ios::in);
    if (adj_mat_file.fail ()) {
        NS_FATAL_ERROR ("File " << adj_mat_file_name.c_str () << " not found");
    }
    vector<vector<int> > array;
    int i = 0;
    int n_nodes = 0;

    while (!adj_mat_file.eof ()) {
        string line;
        getline (adj_mat_file, line);
        if (line == "") {
            NS_LOG_WARN ("WARNING: Ignoring blank row in the array: " << i);
            break;
        }

        istringstream iss (line);
        int element;
        vector<int> row;
        int j = 0;

        while (iss >> element) {
            row.push_back (element);
            j++;
        }

        if (i == 0) {
            n_nodes = j;
        }

        if (j != n_nodes ) {
            NS_LOG_ERROR ("ERROR: Number of elements in line " << i << ": " << j << " not equal to number of elements in line 0: " << n_nodes);
            NS_FATAL_ERROR ("ERROR: The number of rows is not equal to the number of columns! in the adjacency matrix");
        } else {
            array.push_back (row);
        }
        i++;
    }

    if (i != n_nodes) {
        NS_LOG_ERROR ("There are " << i << " rows and " << n_nodes << " columns.");
        NS_FATAL_ERROR ("ERROR: The number of rows is not equal to the number of columns! in the adjacency matrix");
    }

    adj_mat_file.close ();
    return array;
}

vector<vector<double> > readCordinatesFile (std::string node_coordinates_file_name) {
    ifstream node_coordinates_file;
    node_coordinates_file.open (node_coordinates_file_name.c_str (), ios::in);
    if (node_coordinates_file.fail ()) {
        NS_FATAL_ERROR ("File " << node_coordinates_file_name.c_str () << " not found");
    }
    vector<vector<double> > coord_array;
    int m = 0;

    while (!node_coordinates_file.eof ()) {
        string line;
        getline (node_coordinates_file, line);

        if (line == "") {
            NS_LOG_WARN ("WARNING: Ignoring blank row: " << m);
            break;
        }

        istringstream iss (line);
        double coordinate;
        vector<double> row;
        int n = 0;
        while (iss >> coordinate) {
            row.push_back (coordinate);
            n++;
        }

        if (n != 2) {
            NS_LOG_ERROR ("ERROR: Number of elements at line#" << m << " is "  << n << " which is not equal to 2 for node coordinates file");
            exit (1);
        } else {
            coord_array.push_back (row);
        }
        m++;
    }
    node_coordinates_file.close ();
    return coord_array;
}

void printMatrix (const char* description, vector<vector<int> > array) {
    cout << "**** Start " << description << "********" << endl;
    for (size_t m = 0; m < array.size (); m++) {
        for (size_t n = 0; n < array[m].size (); n++) {
            cout << array[m][n] << ' ';
        }
        cout << endl;
    }
    cout << "**** End " << description << "********" << endl;
}

void printCoordinateArray (const char* description, vector<vector<double> > coord_array) {
    cout << "**** Start " << description << "********" << endl;
    for (size_t m = 0; m < coord_array.size (); m++) {
        for (size_t n = 0; n < coord_array[m].size (); n++) {
            cout << coord_array[m][n] << ' ';
        }
        cout << endl;
    }
    cout << "**** End " << description << "********" << endl;
}

// ---------- End of Function Definitions ------------------------------------

