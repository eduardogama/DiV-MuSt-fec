#include "ns3/core-module.h"
#include "ns3/applications-module.h"
#include "ns3/internet-module.h"
#include "ns3/mobility-module.h"
#include "ns3/wifi-module.h"
#include "ns3/netanim-module.h"

#include "ctrl-dash-main.h"
#include "utils.h"

#include "group-user.h"


using namespace ns3;
using namespace std;


NS_LOG_COMPONENT_DEFINE ("LteMain");


void Run(unsigned from, unsigned to, int userId, Ptr<DashController> &controller)
{
  int content = zipf(0.7, 100);

  controller->tryRequest(from, to, content, userId);

  if (controller->hasToRedirect()) {
    controller->DoSendRedirect();
  }
}

int main(int argc, char *argv[])
{
  unsigned n_ap = 0, n_clients = 1;

  uint16_t seed = 0;
  double stopTime = 600.0;
  string AdaptationLogicToUse = "dash::player::RateAndBufferBasedAdaptationLogic"; //dash::player::BufferBasedAdaptationLogic

  string scenarioFiles = GetCurrentWorkingDir() + "/../content/scenario";

  CommandLine cmd;
  cmd.AddValue("stopTime", "The time when the clients will stop requesting segments", stopTime);
  cmd.AddValue("AdaptationLogicToUse", "Adaptation Logic to Use.", AdaptationLogicToUse);
  cmd.AddValue("seed", "Seed Experiment", seed);
  cmd.Parse (argc, argv);

  NetworkTopology network;
  ReadTopology(scenarioFiles + "/tree_l3_link_2", scenarioFiles + "/tree_l3_nodes", network);

  NodeContainer nodes;
  NodeContainer clients;
	nodes.Create(network.getNodes().size());

  for (unsigned int i = 0; i < network.getNodes().size(); i += 1) {
		ostringstream ss;
		ss << network.getNodes().at(i)->getId();
		Names::Add(network.getNodes().at(i)->getType() + ss.str(), nodes.Get( network.getNodes().at(i)->getId() ));
	}

  // Later we add IP Addresses
	NS_LOG_INFO("Assign IP Addresses.");
	InternetStackHelper internet;

	fprintf(stderr, "Installing Internet Stack\n");
	// Now add ip/tcp stack to all nodes.
	internet.Install(nodes);

  // create p2p links
  vector<NetDeviceContainer> netDevices;
  Ipv4AddressHelper address;
  address.SetBase ("10.0.0.0", "255.255.255.0");
  PointToPointHelper p2p;

  for (unsigned int i = 0; i < network.getLinks().size(); i += 1) {
    p2p.SetDeviceAttribute("DataRate", DataRateValue( network.getLinks().at(i)->getRate() )); // Mbit/s

    // And then install devices and channels connecting our topology
    NetDeviceContainer deviceContainer;
    deviceContainer = p2p.Install(nodes.Get(network.getLinks().at(i)->getSrcId()), nodes.Get(network.getLinks().at(i)->getDstId()));

    address.Assign(deviceContainer);
    address.NewNetwork();
    netDevices.push_back(deviceContainer);
  }

  //Store IP adresses
	std::string addr_file = "addresses";
	ofstream out_addr_file(addr_file.c_str());
	for (unsigned int i = 0; i < nodes.GetN(); i++) {
		Ptr<Node> n = nodes.Get(i);
		Ptr<Ipv4> ipv4 = n->GetObject<Ipv4>();
		for (uint32_t l = 1; l < ipv4->GetNInterfaces (); l++) {
			out_addr_file << i <<  " " << ipv4->GetAddress (l, 0).GetLocal () << endl;
		}
	}
	out_addr_file.flush ();
	out_addr_file.close ();

  // %%%%%%%%%%%% Set up the Mobility Position
  MobilityHelper mobility;

	mobility.SetPositionAllocator ("ns3::GridPositionAllocator",
		                          "MinX", DoubleValue (-10.0),
		                          "MinY", DoubleValue (-10.0),
		                          "DeltaX", DoubleValue (20.0),
		                          "DeltaY", DoubleValue (20.0),
		                          "GridWidth", UintegerValue (20),
		                          "LayoutType", StringValue ("RowFirst"));
	mobility.SetMobilityModel ("ns3::ConstantPositionMobilityModel");

  YansWifiChannelHelper channel = YansWifiChannelHelper::Default();
  YansWifiPhyHelper 	  phy     = YansWifiPhyHelper::Default();

  Ptr<ListPositionAllocator> positionAlloc = CreateObject <ListPositionAllocator>();

  for (unsigned int i = 0; i < network.getNodes().size(); i += 1) {
    Ptr<Node> node = nodes.Get(network.getNodes().at(i)->getId());

    size_t found = Names::FindName(node).find("ap");
    if (found != string::npos) {
      mobility.Install(node);

      Ptr<MobilityModel> mob = node->GetObject<MobilityModel>();

      int rng_client = 360/n_clients;
			double x = mob->GetPosition().x, y = mob->GetPosition().y;
			for (size_t i = 0; i < 360; i += rng_client) {
				double cosseno = cos(i);
				double seno    = sin(i);
				positionAlloc->Add(Vector(5*cosseno + x , 5*seno + y, 0));
			}
      NodeContainer c;
			c.Create(n_clients);
			clients.Add(c);

			internet.Install(c);

			WifiHelper wifi;
			WifiMacHelper mac;
	    phy.SetChannel(channel.Create());

			ostringstream ss;
			ss << "ns-3-ssid-" << ++n_ap;
	    Ssid ssid = Ssid(ss.str());

			wifi.SetRemoteStationManager("ns3::AarfWifiManager");
			wifi.SetStandard (WIFI_PHY_STANDARD_80211g);

			mac.SetType("ns3::ApWifiMac", "Ssid", SsidValue (ssid));
			NetDeviceContainer ap_dev =  wifi.Install(phy, mac, node);

			mac.SetType("ns3::StaWifiMac", "Ssid", SsidValue (ssid), "ActiveProbing", BooleanValue (false));
			NetDeviceContainer sta_dev = wifi.Install(phy, mac, c);

			address.Assign(ap_dev);
			address.Assign(sta_dev);
			address.NewNetwork();
    }
  }
  positionAlloc->Add(Vector(0, 0, 0));   // Ap 1
  positionAlloc->Add(Vector(30, 0, 0));   // Ap 2
  positionAlloc->Add(Vector(15, 15, 0)); // node2
  positionAlloc->Add(Vector(15, 30, 0)); // node3

	mobility.SetPositionAllocator(positionAlloc);
	mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
	mobility.Install(clients);

	mobility.Install(nodes.Get(1));
	mobility.Install(nodes.Get(2));
	mobility.Install(nodes.Get(0));
	mobility.Install(nodes.Get(7));

  Ipv4GlobalRoutingHelper::PopulateRoutingTables();
 
  network.setNodeContainers (&nodes);
  network.setClientContainers(&clients);

  // %%%%%%%%%%%% Set up the DASH server
  NS_LOG_INFO("Create Applications.");
  Ptr<Node> n_server = nodes.Get(7);

	string representationStrings = GetCurrentWorkingDir() + "/../../dataset/netflix_vid1.csv";
	fprintf(stderr, "representations = %s\n", representationStrings.c_str ());

  string str_ipv4_server = Ipv4AddressToString(n_server->GetObject<Ipv4>()->GetAddress(1,0).GetLocal());

  DASHServerHelper server(Ipv4Address::GetAny (), 80, str_ipv4_server,
		                      "/content/mpds/", representationStrings, "/content/segments/");

	ApplicationContainer serverApps = server.Install(n_server);
	serverApps.Start (Seconds(0.0));
	serverApps.Stop (Seconds(stopTime));
	//=======================================================================================

  Ptr<DashController> controller = CreateObject<DashController> ();
  n_server->AddApplication(controller);

  controller->Setup(&network, str_ipv4_server, Ipv4Address::GetAny (), 1317);

  controller->SetStartTime(Seconds(0.0));
  controller->SetStopTime(Seconds(100));
  // %%%%%%%%%%%% End Set up the DASH server

  // %%%%%%%%%%%% Set up the DASH clients
  int dst_server = 7;
  unsigned rng_client = 0;
  double rdm 			= 0.0;

  SeedManager::SetRun(time(0));
  Ptr<UniformRandomVariable> uv = CreateObject<UniformRandomVariable> ();

  for (unsigned ap_i = 0; ap_i < network.getNodes().size(); ap_i += 1)
  {
    Ptr<Node> node = nodes.Get(network.getNodes().at(ap_i)->getId());
    size_t found = Names::FindName(node).find("ap");
    if (found != string::npos)
    {
      for (unsigned user = 0; user < n_clients; user++)
      {
        rdm += uv->GetValue();
        int UserId = user + rng_client * n_clients;

        int screenWidth = 1920;
        int screenHeight = 1080;

        stringstream mpd_baseurl;
        mpd_baseurl << "http://" << str_ipv4_server << "/content/mpds/";

        stringstream ssMPDURL;
        ssMPDURL << mpd_baseurl.str() << "vid" << 1 << ".mpd.gz";

        DASHHttpClientHelper player (ssMPDURL.str());
        player.SetAttribute("AdaptationLogic", StringValue(AdaptationLogicToUse));
        player.SetAttribute("StartUpDelay", StringValue("4"));
        player.SetAttribute("ScreenWidth", UintegerValue(screenWidth));
        player.SetAttribute("ScreenHeight", UintegerValue(screenHeight));
        player.SetAttribute("UserId", UintegerValue(UserId));
        player.SetAttribute("AllowDownscale", BooleanValue(true));
        player.SetAttribute("AllowUpscale", BooleanValue(true));
        player.SetAttribute("MaxBufferedSeconds", StringValue("60"));

        ApplicationContainer clientApps;
        clientApps = player.Install(clients.Get(UserId));
        clientApps.Start(Seconds(0.5 + rdm));
        clientApps.Stop(Seconds(stopTime));

        Simulator::Schedule(Seconds(rdm + 0.35), Run, ap_i, dst_server, UserId, controller);
      }
      rng_client++;
    }
  }

  // %%%%%%%%%%%% sort out the simulation
  string dir = CreateDir("../bin-tree");
  AnimationInterface anim(dir + string("/topology.netanim"));

  stringstream gstream;
  gstream << dir << "/output-dash-" << seed << ".csv";
  DASHPlayerTracer::InstallAll(gstream.str());

  Simulator::Stop(Seconds(100));
	Simulator::Run();
	Simulator::Destroy();

  return 0;
}
