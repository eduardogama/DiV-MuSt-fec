/*	   Network topology

       __l1__  __l2__
      /      \/      \
     /       /\       \
    /       /  \       \
   /       /    \       \
   l3     l4     l5      l6
   |\     /|     |\     /|
   | \   / |     | \   / |
   |  \ /  |     |  \ /  |
   |  /\   |     |  /\   |
   |_/  \__|     |_/  \__|
   l7    l8      l9    l10
   |      |       |     |
   c11    c12     c13   c14
*/     
#include "ns3/core-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/network-module.h"
#include "ns3/applications-module.h"
#include "ns3/wifi-module.h"
#include "ns3/mobility-module.h"
#include "ns3/csma-module.h"
#include "ns3/internet-module.h"
#include "ns3/dashplayer-tracer.h"
#include "ns3/node-throughput-tracer.h"
#include "ns3/ipv4-static-routing-helper.h"
#include "ns3/ipv4-list-routing-helper.h"
#include "ns3/ipv4-nix-vector-helper.h"
#include "ns3/flow-monitor-helper.h"
#include "ns3/flow-monitor-module.h"

#include "ns3/uinteger.h"

#include <fstream>
#include <string>
#include <sstream>

#include "dash-utils.h"

#include "ns3/netanim-module.h"

using namespace ns3;


std::string GetCurrentWorkingDir(void)
{
	char buff[250];
	getcwd( buff, 250 );
	std::string current_working_dir(buff);
	return current_working_dir;
}

NS_LOG_COMPONENT_DEFINE ("dash-mptcp");


int main (int argc, char *argv[])
{
	std::string scenarioFiles = GetCurrentWorkingDir() + "/../content/scenario";
	std::string requestsFile = "requests";
	std::string DashTraceFile = "report.csv";
	std::string ServerThroughputTraceFile = "server_throughput.csv";
	std::string RepresentationType = "netflix";
		
	CommandLine cmd;
		
	//default parameters
	cmd.AddValue("DashTraceFile", "Filename of the DASH traces", DashTraceFile);
	cmd.AddValue("ServerThroughputTraceFile", "Filename of the server throughput traces", ServerThroughputTraceFile);
	cmd.AddValue("RepresentationType", "Input representation type name", RepresentationType);
	cmd.Parse (argc, argv);
	
    Config::SetDefault("ns3::TcpSocket::SegmentSize", UintegerValue(1400));
    Config::SetDefault("ns3::TcpSocket::DelAckCount", UintegerValue(0));


	vector<_Link *> linksData;
	vector<_Node *> nodesData;	
	
	io_read_topology(scenarioFiles + "/adj_matrix_1", scenarioFiles + "/nodes", linksData, nodesData);


	NS_LOG_INFO ("Create Nodes");
	NodeContainer nodes;
	nodes.Create(nodesData.size());
	
	std::cout << "Node size = " << nodesData.size() << std::endl;
	for (unsigned int i = 0; i < nodesData.size(); i += 1)
	{
		std::ostringstream ss;
		ss << nodesData.at(i)->getId();
		Names::Add(nodesData.at(i)->getType() + ss.str(), nodes.Get(nodesData.at(i)->getId()));
		std::cout << "Node name = " << nodesData.at(i)->getType() << std::endl;
	}
	
	// Later we add IP Addresses
	NS_LOG_INFO ("Assign IP Addresses.");
//	Ipv4StaticRoutingHelper staticRouting;
	InternetStackHelper internet;
	
//	internet.SetRoutingHelper(staticRouting);
	fprintf(stderr, "Installing Internet Stack\n");
	// Now add ip/tcp stack to all nodes.
	internet.Install(nodes);
	
	// create p2p links
	vector<NetDeviceContainer> netDevices;
	Ipv4AddressHelper address;
	address.SetBase ("10.0.0.0", "255.255.255.0");
	PointToPointHelper p2p;
	for (unsigned int i = 0; i < linksData.size(); i += 1)
	{
//		double errRate = linksData.at(i)->getPLoss();

//		DoubleValue rate(errRate);
//		Ptr<RateErrorModel> em1 = CreateObjectWithAttributes<RateErrorModel> ("RanVar", 
//								StringValue ("ns3::UniformRandomVariable[Min=0.0,Max=1.0]"), "ErrorRate", rate);
//		Ptr<RateErrorModel> em2 = CreateObjectWithAttributes<RateErrorModel> ("RanVar", 
//								StringValue ("ns3::UniformRandomVariable[Min=0.0,Max=1.0]"), "ErrorRate", rate);
	
		p2p.SetDeviceAttribute ("DataRate", DataRateValue ( linksData.at(i)->getRate() )); // 100 Mbit/s
//		p2p.SetChannelAttribute ("Delay", TimeValue ( MilliSeconds (linksData.at(i)->getDelay()) ));
		
//		uint32_t queueSize = 1000000; 
//		p2p.SetQueue("ns3::DropTailQueue", "MaxPackets", UintegerValue(queueSize));
	
		// And then install devices and channels connecting our topology
		NetDeviceContainer deviceContainer;
		deviceContainer = p2p.Install(nodes.Get(linksData.at(i)->getSrcId()), nodes.Get(linksData.at(i)->getDstId()));
//		deviceContainer.Get(0)->SetAttribute("ReceiveErrorModel", PointerValue (em1));
//		deviceContainer.Get(1)->SetAttribute("ReceiveErrorModel", PointerValue (em2));
		address.Assign(deviceContainer);
		address.NewNetwork();
		netDevices.push_back(deviceContainer);
	}
	//Ipv4GlobalRoutingHelper::PopulateRoutingTables ();	
	
//	address.NewNetwork();
	
	//Store IP adresses
	std::string addr_file="addresses";
	ofstream out_addr_file(addr_file.c_str());
	for(unsigned int i=0;i<nodes.GetN();i++){
		Ptr<Node> n = nodes.Get (i);
		Ptr<Ipv4> ipv4 = n->GetObject<Ipv4> ();
		for(uint32_t l=1;l<ipv4->GetNInterfaces();l++){
			out_addr_file << i <<  " " << ipv4->GetAddress(l, 0).GetLocal() << endl;
		}
	}
	out_addr_file.flush();
	out_addr_file.close();
	
	
	// %%%%%%%%%%%% Set up the Mobility Position
	MobilityHelper mobility;
	// setup the grid itself: objects are laid out
	// started from (-100,-100) with 20 objects per row, 
	// the x interval between each object is 5 meters
	// and the y interval between each object is 20 meters
	mobility.SetPositionAllocator ("ns3::GridPositionAllocator",
		                          "MinX", DoubleValue (-10.0),
		                          "MinY", DoubleValue (-10.0),
		                          "DeltaX", DoubleValue (20.0),
		                          "DeltaY", DoubleValue (20.0),
		                          "GridWidth", UintegerValue (20),
		                          "LayoutType", StringValue ("RowFirst"));
	// each object will be attached a static position.
	// i.e., once set by the "position allocator", the
	// position will never change.
	mobility.SetMobilityModel ("ns3::ConstantPositionMobilityModel");
		
	
    YansWifiChannelHelper channel = YansWifiChannelHelper::Default();
    YansWifiPhyHelper phy = YansWifiPhyHelper::Default();
	phy.SetChannel(channel.Create());
	
	int n_ap=0;
	NodeContainer clients;
	Ptr<ListPositionAllocator> positionAlloc = CreateObject <ListPositionAllocator>();
	for (unsigned int i = 0; i < nodesData.size(); i += 1)
	{
		std::size_t found = Names::FindName(nodes.Get( nodesData.at(i)->getId())).find("ap");
		if (found!=std::string::npos)
		{
			mobility.Install(nodes.Get(nodesData.at(i)->getId()));

			NodeContainer ap = nodes.Get(nodesData.at(i)->getId());
		
			Ptr<MobilityModel> mob = (nodes.Get(nodesData.at(i)->getId()))->GetObject<MobilityModel>();
			double x = mob->GetPosition().x;
			double y = mob->GetPosition().y;
			double z = mob->GetPosition().z;
			
			std::cout << "x = " << x << std::endl;
			std::cout << "y = " << y << std::endl;
			std::cout << "z = " << z << std::endl;
			
			
		    int aux = 360/5;
			for (size_t i = 0; i < 360; i += aux) {
				double cosseno = cos(i);
				double seno    = sin(i);
				positionAlloc->Add(Vector(5*cosseno + x , 5*seno + y, 0));
			}

			NodeContainer c;
			c.Create(5);

			clients.Add(c);	
		
			internet.Install(c);
//			internet.Install(ap);
			
			WifiHelper wifi;
			WifiMacHelper mac;
		    
			
			std::ostringstream ss;
			ss << "ns-3-ssid-" << ++n_ap;
		    Ssid ssid = Ssid(ss.str());
			
		
			wifi.SetRemoteStationManager("ns3::AarfWifiManager");
//			wifi.SetStandard (WIFI_PHY_STANDARD_80211g);

			
			mac.SetType("ns3::ApWifiMac", "Ssid", SsidValue (ssid));
			NetDeviceContainer ap_dev =  wifi.Install(phy, mac, ap);
			
			mac.SetType("ns3::StaWifiMac", "Ssid", SsidValue (ssid), "ActiveProbing", BooleanValue (false));
			NetDeviceContainer sta_dev = wifi.Install(phy, mac, c);
			
			address.Assign(ap_dev);
			address.Assign(sta_dev);
//			address.NewNetwork();
		}
	}
	
	mobility.SetPositionAllocator(positionAlloc);    
	mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
	mobility.Install(clients);
	
	
	// %%%%%%%%%%%% End Set up the Mobility Position
	
    Ipv4GlobalRoutingHelper::PopulateRoutingTables();

	// %%%%%%%%%%%% Set up the DASH server
	
	std::cout << Names::FindName(nodes.Get(0)) << std::endl;
	stringstream gstream;

    Ptr<Node> n = nodes.Get(0);
    Ptr<Ipv4> ipv4 = n->GetObject<Ipv4> ();    
    gstream << ipv4->GetAddress(1,0).GetLocal();
    
    std::cout << gstream.str() << std::endl;

    NS_LOG_INFO("Create Applications.");
    string srv_ip = gstream.str();
    gstream.str("");

	
    string representationStrings = "/home/eduardo/dataset/netflix_vid1.csv";
	fprintf(stderr, "representations = %s\n", representationStrings.c_str ());

	DASHServerHelper server (Ipv4Address::GetAny (), 80,  srv_ip, 
		                   "/content/mpds/", representationStrings, "/content/segments/");
	
	ApplicationContainer serverApps;	                   
	serverApps = server.Install(nodes.Get(0));
	serverApps.Start (Seconds(0.0));
	serverApps.Stop (Seconds(500));

	// %%%%%%%%%%%% Set up a client with DASH

	std::string AdaptationLogicToUse = "dash::player::RateAndBufferBasedAdaptationLogic";
	std::stringstream mpd_baseurl;
	mpd_baseurl << "http://" << srv_ip << "/content/mpds/";
	int videoId = 0;
	
	int screenWidth = 1920;
	int screenHeight = 1080;
	
	
	for (unsigned int i = 0; i < clients.GetN(); i += 1)
	{
		std::stringstream ssMPDURL;
		ssMPDURL << mpd_baseurl.str() << "vid" << videoId+1 << ".mpd.gz";
		
		DASHHttpClientHelper player (ssMPDURL.str ());
		player.SetAttribute("AdaptationLogic", StringValue(AdaptationLogicToUse));
		player.SetAttribute("StartUpDelay", StringValue("4"));
		player.SetAttribute("ScreenWidth", UintegerValue(screenWidth));
		player.SetAttribute("ScreenHeight", UintegerValue(screenHeight));
		player.SetAttribute("UserId", UintegerValue(i));
		player.SetAttribute("AllowDownscale", BooleanValue(true));
		player.SetAttribute("AllowUpscale", BooleanValue(true));
		player.SetAttribute("MaxBufferedSeconds", StringValue("60"));

		ApplicationContainer clientApps;
		clientApps = player.Install (clients.Get(i));
		clientApps.Start (Seconds (0.5));
		clientApps.Stop (Seconds (300));
	}
	

	// %%%%%%%%%%%% sort out the simulation

    AnimationInterface anim("topology.netanim");
    
	Simulator::Stop(Seconds(300));
	Simulator::Run();
	Simulator::Destroy();

	DASHPlayerTracer::Destroy();

	return 0;
}
