#ifndef TREE_UTILS_HH_
#define TREE_UTILS_HH_

#include "ns3/application.h"

#include <string>
#include <vector>

#include <unordered_map>
#include <list>

using namespace ns3;
using namespace std;

struct node
{
    public:
		int key_value;
		node* left;
		node* right;
};

class BTree
{
    public:
        BTree();
        ~BTree();
 
        void insert(int key);
        node *search(int key);
        void destroy_tree();
 
    private:
        void destroy_tree(node *leaf);
        void insert(int key, node *leaf);
        node *search(int key, node *leaf);
         
        node *root;
};

BTree::BTree()
{
	root = NULL;
}

BTree::~BTree()
{
	destroy_tree();
}

void BTree::destroy_tree(node *leaf)
{
	if(leaf!=NULL)
	{
		destroy_tree(leaf->left);
		destroy_tree(leaf->right);
		delete leaf;
	}
}

void BTree::insert(int key, node *leaf)
{
	if(key < leaf->key_value) {
		if(leaf->left != NULL) {
			insert(key, leaf->left);
		} else {
			leaf->left = new node;
			leaf->left->key_value=key;
			leaf->left->left=NULL;    //Sets the left child of the child node to null
			leaf->left->right=NULL;   //Sets the right child of the child node to null
		}  
	} else if(key >= leaf->key_value) {
		if(leaf->right != NULL) {
			insert(key, leaf->right);
		} else {
			leaf->right = new node;
			leaf->right->key_value=key;
			leaf->right->left=NULL;  //Sets the left child of the child node to null
			leaf->right->right=NULL; //Sets the right child of the child node to null
		}
	}
}

node *BTree::search(int key, node *leaf)
{
	if(leaf!=NULL)
	{
		if(key==leaf->key_value)
			return leaf;
		if(key<leaf->key_value)
			return search(key, leaf->left);
		else
			return search(key, leaf->right);
	}
	else return NULL;
}

void BTree::insert(int key)
{
	if(root!=NULL)
		insert(key, root);
	else
	{
		root=new node;
		root->key_value=key;
		root->left=NULL;
		root->right=NULL;
	}
}

node *BTree::search(int key)
{
	return search(key, root);
}

void BTree::destroy_tree()
{
	destroy_tree(root);
}

//void printPathsRecur(node* node, int path[], int pathLen);  
//void printArray(int ints[], int len);  

///*Given a binary tree, print out all of its root-to-leaf  
//paths, one per line. Uses a recursive helper to do the work.*/
//void printPaths(node* node)  
//{  
//    int path[1000];  
//    printPathsRecur(node, path, 0);  
//}  

///* Recursive helper function -- given a node,  
//and an array containing the path from the root 
//node up to but not including this node,  
//print out all the root-leaf paths.*/
//void printPathsRecur(node* node, int path[], int pathLen)  
//{  
//    if (node == NULL)  
//        return;  
//      
//    /* append this node to the path array */
//    path[pathLen] = node->data;  
//    pathLen++;  
//      
//    /* it's a leaf, so print the path that led to here */
//    if (node->left == NULL && node->right == NULL)  
//    {  
//        printArray(path, pathLen);  
//    }  
//    else
//    {  
//        /* otherwise try both suBTrees */
//        printPathsRecur(node->left, path, pathLen);  
//        printPathsRecur(node->right, path, pathLen);  
//    }  
//}

///* UTILITY FUNCTIONS */
///* Utility that prints out an array on a line. */
//void printArray(int ints[], int len)  
//{  
//    int i;  
//    for (i = 0; i < len; i++)  
//    {  
//        cout << ints[i] << " ";  
//    }  
//    cout<<endl;  
//}  
//  
///* utility that allocates a new node with the  
//given data and NULL left and right pointers. */
//node* newnode(int data)  
//{  
//    node* Node = new node(); 
//    Node->data = data;  
//    Node->left = NULL;  
//    Node->right = NULL;  
//      
//    return(Node);  
//}

#endif // TREE_UTILS_HH_
