#include "ns3/core-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/network-module.h"
#include "ns3/applications-module.h"
#include "ns3/wifi-module.h"
#include "ns3/mobility-module.h"
#include "ns3/csma-module.h"
#include "ns3/internet-module.h"
#include "ns3/dashplayer-tracer.h"
#include "ns3/node-throughput-tracer.h"
#include "ns3/ipv4-static-routing-helper.h"
#include "ns3/ipv4-list-routing-helper.h"
#include "ns3/ipv4-nix-vector-helper.h"
#include "ns3/flow-monitor-helper.h"
#include "ns3/flow-monitor-module.h"

#include "ns3/uinteger.h"
#include "ns3/netanim-module.h"


#include <map>
#include <fstream>
#include <string>
#include <sstream>
#include <ctime>

#include "dash-utils.h"
#include "vod-utils.h"
#include "vod-server.h"
#include "vod-controller.h"

#include "tree-utils.h"
#include "graph-utils.h"


using namespace ns3;

vector<GroupUser *> groups = NetworkSingleton::getInstance()->getGroups();

std::string dir;

std::vector<double> videos(30, 9.294336); //MB

double averageArrival = 5;
double lamda = 1 / averageArrival;
std::mt19937 rng (0);
std::vector<double> sum_probs;

std::exponential_distribution<double> poi (lamda);
std::uniform_real_distribution<double> unif(0, 1);

double sumArrivalTimes = 0;
double newArrivalTime;

NS_LOG_COMPONENT_DEFINE ("DashTreeL3");

class Experiment {
    public:
        Experiment();
        ~Experiment();
        
        bool CreateDir(string name);
        string getDirectory();
        void setDirectory(string _dir);
    private:
        string dir;
};

Experiment::Experiment(){}
Experiment::~Experiment(){}

bool Experiment::CreateDir(string name) {
    dir = name;
    return system(string(string("mkdir -p ") + name).c_str()) != -1;
}

string Experiment::getDirectory(){
    return dir;
}

void Experiment::setDirectory(string _dir){
    dir = _dir;
}

std::string GetCurrentWorkingDir(void)
{
	char buff[250];
	getcwd( buff, 250 );
	std::string current_working_dir(buff);
	return current_working_dir;
}

double poisson()
{
	newArrivalTime = poi.operator() (rng);// generates the next random number in the distribution 
	sumArrivalTimes = sumArrivalTimes + newArrivalTime;
	std::cout << "newArrivalTime: " << newArrivalTime  << ", sumArrivalTimes: " << sumArrivalTimes << std::endl;
	if (sumArrivalTimes < 3.6) {
		sumArrivalTimes = 3.6;
	}
	return sumArrivalTimes;
}

int zipf(double alpha, int n)
{
	static int first = true;      // Static first time flag
	static double c = 0;          // Normalization constant                 
	double z;                     // Uniform random number (0 < z < 1)
	int    zipf_value;            // Computed exponential value to be returned
	int    i;                     // Loop counter
	int    low, high, mid;        // Binary-search bounds

	// Compute normalization constant on first call only
	if (first == true)
	{
		sum_probs.reserve(n+1); // Pre-calculated sum of probabilities
		sum_probs.resize(n+1);
		for (i = 1; i <= n; i++)
			c = c + (1.0 / pow((double) i, alpha));
		c = 1.0 / c;

		//sum_probs = malloc((n+1)*sizeof(*sum_probs));
		sum_probs[0] = 0;
		for (i = 1; i <= n; i++) {
			sum_probs[i] = sum_probs[i-1] + c / pow((double) i, alpha);
		}
		first = false;
	}

	// Pull a uniform random number (0 < z < 1)
	do {
		z = unif.operator()(rng);
	} while ((z == 0) || (z == 1));

	//for (i=0; i<=n; i++)
	//{
	//  std::cout << "sum_probs:  " << sum_probs[i] << std::endl;
	//}
	//std::cout << "z:  " << z << std::endl;
	// Map z to the value
	low = 1; high = n;
	do {
		mid = floor((low+high)/2);
		if (sum_probs[mid] >= z && sum_probs[mid-1] < z) {
			zipf_value = mid;
			break;
		} else if (sum_probs[mid] >= z) {
			high = mid-1;
		} else {
			low = mid+1;
		}
	} while (low <= high);
	std::cout << "ZIPF:  " << zipf_value << std::endl;
	// Assert that zipf_value is between 1 and N
	assert((zipf_value >=1) && (zipf_value <= n));
	
	return (zipf_value);
}
void CreateClientApp(){

//	int screenWidth = 1920;
//	int screenHeight = 1080;
	
//	std::stringstream mpd_baseurl;
//	mpd_baseurl << "http://" << NetworkSingleton::getInstance()->getGraph()->srv_ip << "/content/mpds/";
//	
//	std::stringstream ssMPDURL;
//	ssMPDURL << mpd_baseurl.str() << "vid" << 1 << ".mpd.gz";

//	DASHHttpClientHelper player (ssMPDURL.str ());
//	player.SetAttribute("AdaptationLogic", StringValue(NetworkSingleton::getInstance()->AdaptationLogicToUse));
//	player.SetAttribute("StartUpDelay", StringValue("4"));
//	player.SetAttribute("ScreenWidth", UintegerValue(screenWidth));
//	player.SetAttribute("ScreenHeight", UintegerValue(screenHeight));
//	player.SetAttribute("UserId", UintegerValue(NetworkSingleton::getInstance()->UserId));
//	player.SetAttribute("AllowDownscale", BooleanValue(true));
//	player.SetAttribute("AllowUpscale", BooleanValue(true));
//	player.SetAttribute("MaxBufferedSeconds", StringValue("60"));
//			
//	ApplicationContainer clientApps;
//	clientApps = player.Install (clients.Get(j));

//	clientApps.Start(Seconds(0.5 + NetworkSingleton::getInstance()->rdm));
//	clientApps.Stop (Seconds (NetworkSingleton::getInstance()->stopTime));
}

void ExecutionFlow(unsigned int i, int cont, int src, int dest){
	SetupRequestRoutingEntry(i,cont,src,dest);
//	CreateClientApp();		
}

int main (int argc, char *argv[])
{
	int seedValue = time(0);
	RngSeedManager::SetSeed(seedValue + 10000);
	srand(seedValue);
	rng.seed(seedValue);

//	std::vector<int> cont(100,0);
//	for (unsigned int i = 0; i < 100; i += 1) {
//		cont[zipf(0.7,100)]++;
//	}
//	for (unsigned int i = 0; i < 100; i += 1) {
//		std::cout << cont[i] << std::endl;
//	}
	
	std::string scenarioFiles = GetCurrentWorkingDir() + "/../content/scenario";
	std::string requestsFile = "requests";
	std::string DashTraceFile = "report.csv";
	std::string ServerThroughputTraceFile = "server_throughput.csv";
	std::string RepresentationType = "netflix";

	std::string AdaptationLogicToUse = "dash::player::RateAndBufferBasedAdaptationLogic";
	
	int stopTime = 10;
	int seed = 0;
	CommandLine cmd;
		
	//default parameters
	cmd.AddValue("DashTraceFile", "Filename of the DASH traces", DashTraceFile);
	cmd.AddValue("ServerThroughputTraceFile", "Filename of the server throughput traces", ServerThroughputTraceFile);
	cmd.AddValue("RepresentationType", "Input representation type name", RepresentationType);
    cmd.AddValue("stopTime", "The time when the clients will stop requesting segments", stopTime);
    cmd.AddValue("AdaptationLogicToUse", "Adaptation Logic to Use.", AdaptationLogicToUse);    
    cmd.AddValue("seed", "Seed experiment.", seed);	
	cmd.Parse (argc, argv);

//	Config::SetDefault("ns3::TcpSocket::SegmentSize", UintegerValue (1446));
//	Config::SetDefault("ns3::TcpSocket::SndBufSize", UintegerValue (524288));
//	Config::SetDefault("ns3::TcpSocket::RcvBufSize", UintegerValue (524288));

	vector<_Link *> linksData;
	vector<_Node *> nodesData;
	
	io_read_topology(scenarioFiles + "/tree_l3_link_2", scenarioFiles + "/tree_l3_nodes", linksData, nodesData);


	NS_LOG_INFO ("Create Nodes");
	NodeContainer nodes;
	nodes.Create( nodesData.size() );
	
	std::cout << "Node size = " << nodesData.size() << std::endl;
	for (unsigned int i = 0; i < nodesData.size(); i += 1) {
		std::ostringstream ss;
		ss << nodesData.at(i)->getId();
		Names::Add(nodesData.at(i)->getType() + ss.str(), nodes.Get( nodesData.at(i)->getId() ));
		std::cout << "Node name " << i << " = " << nodesData.at(i)->getType() << std::endl;
	}
	
	// Later we add IP Addresses
	NS_LOG_INFO("Assign IP Addresses.");
	InternetStackHelper internet;
	
	fprintf(stderr, "Installing Internet Stack\n");
	// Now add ip/tcp stack to all nodes.
	internet.Install(nodes);
	
	vector<Edge> edges;
	
	// create p2p links
	vector<NetDeviceContainer> netDevices;
	Ipv4AddressHelper address;
	address.SetBase ("10.0.0.0", "255.255.255.0");
	PointToPointHelper p2p;
	for (unsigned int i = 0; i < linksData.size(); i += 1) {
		std::cout << "Datarate(" << linksData.at(i)->getSrcId()
				  << "," << linksData.at(i)->getDstId()
				  << ") = "<< std::setprecision (std::numeric_limits<double>::digits10 + 1) << linksData.at(i)->getRate() << std::endl;
		
		p2p.SetDeviceAttribute("DataRate", DataRateValue( linksData.at(i)->getRate() )); // Mbit/s
		
		// And then install devices and channels connecting our topology
		NetDeviceContainer deviceContainer;
		deviceContainer = p2p.Install(nodes.Get(linksData.at(i)->getSrcId()), nodes.Get(linksData.at(i)->getDstId()));

		address.Assign(deviceContainer);
		address.NewNetwork();
		netDevices.push_back(deviceContainer);
		
		edges.push_back({linksData.at(i)->getSrcId(), linksData.at(i)->getDstId(), linksData.at(i)->getRate()});
		
		Ptr<Node> nsrc = nodes.Get(linksData.at(i)->getSrcId());
		Ptr<Ipv4> ipv4src = nsrc->GetObject<Ipv4>();
		
		Ptr<Node> ndest = nodes.Get(linksData.at(i)->getDstId());
		Ptr<Ipv4> ipv4dest = ndest->GetObject<Ipv4>();
		
		int32_t int_prev = -1;
		for(uint32_t l = 1; l < ipv4src->GetNInterfaces(); l++) {
			
			for(uint32_t l1 = 1; l1 < ipv4dest->GetNInterfaces(); l1++) {	
				int_prev = ipv4dest->GetInterfaceForPrefix(ipv4src->GetAddress(l, 0).GetLocal(), ipv4src->GetAddress(l, 0).GetMask());
				if (int_prev != -1) break;
			}
			
			string ipsrc = Ipv4AddressToString(ipv4src->GetAddress(l, 0).GetLocal());

			if(int_prev != -1 && cluster.find(ipsrc) == cluster.end()) {
				cluster.insert(make_pair(ipsrc, ClusterNode()));
			
				cluster[ipsrc].setCapacity(linksData.at(i)->getRate());
				cluster[ipsrc].setTargetCapacity(linksData.at(i)->getRate());
				cluster[ipsrc].setSrcId(linksData.at(i)->getSrcId());
				cluster[ipsrc].setDstId(linksData.at(i)->getDstId());
				cluster[ipsrc].ipv4src = ipv4src;
				cluster[ipsrc].ipv4addr = l;
				
				break;
			}
		}
	}
	
	for (auto const& pair : cluster) {
		std::cout << "{" << pair.first << "}\n";
	}
	
	Graph graph(edges, nodes.GetN());
	graph.printGraph();
	NetworkSingleton::getInstance()->setGraph(&graph);
	NetworkSingleton::getInstance()->setNodes(&nodes);

	
	//Store IP adresses
	std::string addr_file = "addresses";
	ofstream out_addr_file(addr_file.c_str());
	for(unsigned int i = 0; i < nodes.GetN(); i++) {
		Ptr<Node> n = nodes.Get(i);
		Ptr<Ipv4> ipv4 = n->GetObject<Ipv4>();
		for(uint32_t l = 1; l < ipv4->GetNInterfaces(); l++) {
			out_addr_file << i <<  " " << ipv4->GetAddress(l, 0).GetLocal() << endl;
			
			graph.setInterfaces(i, Ipv4AddressToString(ipv4->GetAddress(l, 0).GetLocal()));
		}
	}
	out_addr_file.flush();
	out_addr_file.close();
	
	// %%%%%%%%%%%% Set up the DASH server
	
	stringstream gstream;

    Ptr<Node> n = nodes.Get(7);
    Ptr<Ipv4> ipv4 = n->GetObject<Ipv4> ();    
    gstream << ipv4->GetAddress(1,0).GetLocal();
    
    std::cout << "CDN Server = " << gstream.str() << std::endl;

	//=======================================================================================

	// %%%%%%%%%%%% Set up a CDN DASH Server     
    NS_LOG_INFO("Create Applications.");
    string srv_ip = gstream.str();
    gstream.str("");
	
    string representationStrings = GetCurrentWorkingDir() + "/../../dataset/netflix_vid2.csv";
	fprintf(stderr, "representations = %s\n", representationStrings.c_str ());

	DASHServerHelper server (Ipv4Address::GetAny (), 80,  srv_ip, 
		                   "/content/mpds/", representationStrings, "/content/segments/");
	
	ApplicationContainer serverApps;	                   
	serverApps = server.Install(nodes.Get(7));
	serverApps.Start (Seconds(0.0));
	serverApps.Stop (Seconds(stopTime));
	
	
	// %%%%%%%%%%%% Set up the Mobility Position
	MobilityHelper mobility;
	// setup the grid itself: objects are laid out
	// started from (-100,-100) with 20 objects per row, 
	// the x interval between each object is 5 meters
	// and the y interval between each object is 20 meters
	mobility.SetPositionAllocator ("ns3::GridPositionAllocator",
		                          "MinX", DoubleValue (-10.0),
		                          "MinY", DoubleValue (-10.0),
		                          "DeltaX", DoubleValue (20.0),
		                          "DeltaY", DoubleValue (20.0),
		                          "GridWidth", UintegerValue (20),
		                          "LayoutType", StringValue ("RowFirst"));
	// each object will be attached a static position.
	// i.e., once set by the "position allocator", the
	// position will never change.
	mobility.SetMobilityModel ("ns3::ConstantPositionMobilityModel");
		
    YansWifiChannelHelper channel = YansWifiChannelHelper::Default();
    YansWifiPhyHelper phy = YansWifiPhyHelper::Default();

	int n_ap=0, n_clients=5, dest=7;
	unsigned aux1=0;
	NodeContainer clients;
	
	Ptr<ListPositionAllocator> positionAlloc = CreateObject <ListPositionAllocator>();
	for (unsigned int i = 0; i < nodesData.size(); i += 1)
	{
		std::size_t found = Names::FindName(nodes.Get( nodesData.at(i)->getId())).find("ap");
		if (found!=std::string::npos)
		{
			mobility.Install(nodes.Get(nodesData.at(i)->getId()));

			NodeContainer ap = nodes.Get(nodesData.at(i)->getId());
		
			Ptr<MobilityModel> mob = (nodes.Get(nodesData.at(i)->getId()))->GetObject<MobilityModel>();
			double x = mob->GetPosition().x;
			double y = mob->GetPosition().y;
			double z = mob->GetPosition().z;
			
			std::cout << "[x = " << x << "][y = " << y << "][z = " << z << "]" << std::endl;
			
			
		    int aux = 360/n_clients;
			for (size_t i = 0; i < 360; i += aux)
			{
				double cosseno = cos(i);
				double seno    = sin(i);
				positionAlloc->Add(Vector(5*cosseno + x , 5*seno + y, 0));
			}

			NodeContainer c;
			c.Create(n_clients);
			clients.Add(c);	
		
			internet.Install(c);
			
			WifiHelper wifi;
			WifiMacHelper mac;
		    phy.SetChannel(channel.Create());
			
			std::ostringstream ss;
			ss << "ns-3-ssid-" << ++n_ap;
		    Ssid ssid = Ssid(ss.str());
			
		
			wifi.SetRemoteStationManager("ns3::AarfWifiManager");
			wifi.SetStandard (WIFI_PHY_STANDARD_80211g);

			
			mac.SetType("ns3::ApWifiMac", "Ssid", SsidValue (ssid));
			NetDeviceContainer ap_dev =  wifi.Install(phy, mac, ap);
			
			mac.SetType("ns3::StaWifiMac", "Ssid", SsidValue (ssid), "ActiveProbing", BooleanValue (false));
			NetDeviceContainer sta_dev = wifi.Install(phy, mac, c);
			
			address.Assign(ap_dev);
			address.Assign(sta_dev);
			address.NewNetwork();
			
			mobility.SetPositionAllocator(positionAlloc);    
			mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
			mobility.Install(c);
			// %%%%%%%%%%%% End Set up the Mobility Position
			
			// %%%%%%%%%%%% Set up a client with DASH
			NetworkSingleton::getInstance()->getGraph()->srv_ip = srv_ip;
			
			std::stringstream mpd_baseurl;
			mpd_baseurl << "http://" << NetworkSingleton::getInstance()->getGraph()->srv_ip << "/content/mpds/";
//			int videoId = 0;
	
//			int screenWidth = 1920;
//			int screenHeight = 1080;
			
			SeedManager::SetRun(time(0));
			Ptr<UniformRandomVariable> uv = CreateObject<UniformRandomVariable> ();
		    double rdm = 0.0;
			for (unsigned int j = 0; j < c.GetN(); j += 1)
			{
				int cont = zipf(0.7, 100);
//
//				std::stringstream ssMPDURL;
//				ssMPDURL << mpd_baseurl.str() << "vid" << videoId+1 << ".mpd.gz";
//		
//				DASHHttpClientHelper player (ssMPDURL.str ());
//				player.SetAttribute("AdaptationLogic", StringValue(AdaptationLogicToUse));
//				player.SetAttribute("StartUpDelay", StringValue("4"));
//				player.SetAttribute("ScreenWidth", UintegerValue(screenWidth));
//				player.SetAttribute("ScreenHeight", UintegerValue(screenHeight));
//				player.SetAttribute("UserId", UintegerValue(j+aux1*n_clients));
//				player.SetAttribute("AllowDownscale", BooleanValue(true));
//				player.SetAttribute("AllowUpscale", BooleanValue(true));
//				player.SetAttribute("MaxBufferedSeconds", StringValue("60"));
//		
//				rdm += uv->GetValue();
//						
//				ApplicationContainer clientApps;
//				clientApps = player.Install (clients.Get(j));
//		
//				clientApps.Start(Seconds(0.5 + rdm));
//				clientApps.Stop (Seconds (stopTime));

				NetworkSingleton::getInstance()->rdm += uv->GetValue();
				NetworkSingleton::getInstance()->UserId = j+aux1*n_clients;

				Simulator::Schedule(Seconds(rdm + 0.25), ExecutionFlow, j+aux1*n_clients, cont, i, dest);
			}
			aux1++;
		}
	}
	
    Ipv4GlobalRoutingHelper::PopulateRoutingTables();
  
	NetworkSingleton::getInstance()->setClients(&clients);

	// %%%%%%%%%%%% sort out the simulation
	Experiment exp;

    gstream << "../tree-l3-2";
    if (!exp.CreateDir(gstream.str())) {
        printf("Error creating directory!n");
        exit(1);
    }
    gstream.str("");


    gstream << exp.getDirectory() << "/output-dash-" << seed << ".csv";
    DASHPlayerTracer::InstallAll(gstream.str());
    gstream.str("");

    gstream << exp.getDirectory() << "/throughput-" << seed << ".csv";
    NodeThroughputTracer::InstallAll(gstream.str());
    gstream.str("");

    // Flow Monitor -----------------------------------------------------------
//    FlowMonitorHelper flowmon;
//    Ptr<FlowMonitor> monitor = flowmon.InstallAll();
//    monitor->Start (Seconds (0)); monitor->Stop (Seconds (stopTime));
    
    AnimationInterface anim(exp.getDirectory() + std::string("/topology.netanim"));

	Simulator::Stop(Seconds(stopTime));
	Simulator::Run();

//	monitor->SetAttribute("DelayBinWidth", DoubleValue(0.01));
//	monitor->SetAttribute("JitterBinWidth", DoubleValue(0.01));
//	monitor->SetAttribute("PacketSizeBinWidth", DoubleValue(1));
//	monitor->CheckForLostPackets();
//	monitor->SerializeToXmlFile (exp.getDirectory() + string("/netflow.flowmon"), true, true);

	Simulator::Destroy();
	DASHPlayerTracer::Destroy();
	
	
	for(auto &group : groups) {
		std::cout << "GROUP : " << group->getId() << std::endl;
		for(auto &user : group->getUsers()){
			std::cout << "-> User(" << user->getId() << ") : " << user->getIp() << std::endl;
		}
	}
	
	return 0;
}
