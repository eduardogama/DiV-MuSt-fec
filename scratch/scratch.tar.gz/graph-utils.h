#ifndef GRAPH_UTILS_HH_
#define GRAPH_UTILS_HH_

#include "ns3/application.h"


#include <iostream>
#include <vector>
#include <string>

#include <unordered_map>
#include <list>

using namespace ns3;
using namespace std;


// data structure to store graph edges
struct Edge {
	int src, dest;
	double rate;
};


// class to represent a graph object
class Graph
{
	public:
		string srv_ip;
		
		// construct a vector of vectors to represent an adjacency list
		vector<vector<unsigned>> adjList;
		
		vector< vector<string> > interfaceNode;
		
		vector<int> datarate;

		unsigned size;
		
		vector<int> route;
		
		// Graph Constructor
		Graph(vector<Edge> const &edges, int N)
		{
			datarate.resize(N*N);
					
			interfaceNode.resize(N);
			
			// resize the vector to N elements of type vector<int>
			adjList.resize(N);
		
			// add edges to the directed graph
			for (auto &edge: edges)
			{
				// insert at the end
				adjList[edge.src].push_back(edge.dest);

				// Uncomment below line for undirected graph
				 adjList[edge.dest].push_back(edge.src);
				 
				 datarate[edge.src*N + edge.dest] = edge.rate;
			}
			
			size = N;
		}
		
		void setInterfaces(int i, std::string addr){
			interfaceNode[i].push_back(addr);
		}
		
		// print adjacency list representation of graph
		void printGraph()
		{
			for (unsigned i = 0; i < size; i++)
			{
				// print current vertex number
				cout << i << " --> ";

				// print all neighboring vertices of vertex i
				for (int v : adjList[i])
					cout << v << " ";
				cout << endl;
			}
		}
		
		bool dijkstra(unsigned s, unsigned t)
		{
			const unsigned inf = 0xFFFFFFFF;

			vector<unsigned> dist(this->size,inf);
			vector<unsigned> prev(this->size,inf);
			vector<bool> pego(this->size,false);

			dist[t] = 0;
			prev[t] = t;
			pego[t] = true;

			unsigned k = t, min = inf;
			unsigned assegure = 0;
			do
			{
				for (unsigned i = 0; i < adjList[k].size(); i++){
				    if (!pego[adjList[k][i]]){
				        if (dist[k] + 1 < dist[ adjList[k][i] ]){
				            prev[adjList[k][i]] = k;
				            dist[adjList[k][i]] = dist[k] + 1;
				        }
				    }
				}
				
				k = 0;
				min = inf;
				
				for (unsigned i = 0; i < adjList.size(); i++){
				    if (!pego[i] && dist[i] < min){
				        min = dist[i];
						k = i;
				    }
				}
				
				pego[k] = true;
				
				if (assegure++ >= size) //grafo disconexo
				    return false;    
				    
			} while (k!=s);

			k = s;

			route.clear();
			do
			{
				route.push_back(k);
				k = prev[k];
			} while (prev[k] != k);
			route.push_back(k);
					
			return true;
		}
};


#endif // GRAPH_UTILS_HH_
