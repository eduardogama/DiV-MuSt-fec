#ifndef VOD_UTILS_HH_
#define VOD_UTILS_HH_

#include "ns3/internet-module.h"

#include "graph-utils.h"

#include <string>
#include <vector>

#include <unordered_map>
#include <list>

using namespace ns3;


class EndUser {
	public:
		EndUser(){}
	
		void setId(unsigned int _id) {this->stream_id = _id;}
		unsigned int getId() {return this->stream_id;}
		
		void setIp(std::string _ip) {this->user_ip = _ip;}
		std::string getIp() {return this->user_ip;}

		void setContent(int c){this->content = c;}
		int getContent(){return this->content;}
		
	private:

		unsigned int stream_id;
		std::string user_ip;
		
		int content;
};

class GroupUser {
	public:
		GroupUser(){}
		
		void setId(std::string _id) {this->group_id = _id;}
		std::string getId() {return this->group_id;}
		
		void addUser(EndUser *user){this->users.push_back(user);}
		EndUser *getUser(int i){return this->users.at(i);}
				
		void addAddress(Ipv4Address addr){address = addr;}
		Ipv4Address getAddress(){return this->address;}
		
		void setContent(int c){this->content = c;}
		int getContent(){return this->content;}
		
		void setIpv4(Ptr<Ipv4> &ipv4){this->ipv4 = ipv4;}
		Ptr<Ipv4> getIpv4(){return this->ipv4;}
		
		void setSrc(int src){this->src = src;}
		int getSrc(){return this->src;}
		
		void setDst(int dest){this->dst = dest;}
		int getDst(){return this->dst;}
		
		void setRoute(vector<int> &route) {this->route = route;}
		vector<int> &getRoute() {return this->route;}
		int getRoute(int i){return this->route[i];}
		
		void setServerIp(std::string server_ip) {this->server_ip = server_ip;}
		std::string getServerIp() {return this->server_ip;}
		
		std::vector<EndUser *> getUsers(){return this->users;}
		
	private:
			
		std::string group_id;
		std::string server_ip;
	
		vector<EndUser *> users;
		Ipv4Address address;
		
		Ptr<Ipv4> ipv4;
		
		int content;
		
		int src;
		int dst;
	
	public:
		vector<int> route;
		int current = 0;
};

class NetworkSingleton
{
    public:
        static NetworkSingleton* getInstance() {
        	if (instance == 0)
				instance = new NetworkSingleton();
			return instance;    
    	}
    	
    	void setGraph(Graph *graph) {this->graph = graph;}
    	Graph *getGraph() {return this->graph;}
    	
    	void setNodes(NodeContainer *nodes) {this->nodes = nodes;}
    	NodeContainer *getNodes() {return this->nodes;}
    	
    	void setClients(NodeContainer *clients) {this->clients = clients;}
    	NodeContainer *getClients() {return this->clients;}
    	
        vector<GroupUser *> &getGroups() {return this->groups;}
        
    private:
        static NetworkSingleton* instance;

        NetworkSingleton(){}
        
        Graph *graph;
        
		vector<GroupUser *> groups;

	public:
        
        NodeContainer *nodes;
        NodeContainer *clients;

		string AdaptationLogicToUse = "dash::player::RateAndBufferBasedAdaptationLogic";	
		int stopTime = 10;
		double rdm = 0.0;
		int UserId;
		int seed = 0;
		bool DoSendRedirect = false;
		
		string srv_ip;
};

class ClusterNode {
	public:
		ClusterNode() {}
//		ClusterNode (int _id) {this->id = _id;}
//		void addLink(unsigned c) {this->capacity.push_back(c);}
		void Reset() {this->target_capacity = 0;}
		
		double getTargetCapacity() {return this->target_capacity;}
		void setTargetCapacity(double tc) {this->target_capacity = tc;}

		double geCapacity() {return this->capacity;}
		void setCapacity(double tc) {this->capacity = tc;}

		void setSrcId(int srcid) {this->srcid = srcid;}
		int getSrcId() {return this->srcid;}

		void setDstId(int dstid) {this->dstid = dstid;}
		int getDstId() {return this->dstid;}

		double target_capacity;
		double capacity;
		int srcid, dstid;
		
		Ptr<Ipv4> ipv4src;
		int ipv4addr;
		
		vector<string> str_groups;
		vector<GroupUser *> groups;		

};
std::map<std::string, ClusterNode> cluster;

class CacheService {
	public:
		CacheService(unsigned n, unsigned _csize=0){this->capacity = n; this->csize = _csize;}
		
		void refer(string x, unsigned size) {
			if(ma.find(x) == ma.end()) {
				if(dq.size() == capacity) {
					string last = dq.back();
					
					dq.pop_back();
					
					ma.erase(last);
				}
			} else {
				dq.erase(ma[x]);
			}
			
			dq.push_front(x);
			ma[x] = dq.begin();
			
			csize += size;
		}
		
		void display() {
			for(auto it = dq.begin(); it != dq.end(); it++) {
				cout << (*it) << " ";
			}
			cout << endl;
		}
		
	private:
		list<string> dq;
	
		unordered_map<string, list<string>::iterator > ma;
	    unsigned capacity; // maximum capacity of cache
	    unsigned csize;
};

/* Null, because instance will be initialized on demand. */
NetworkSingleton* NetworkSingleton::instance = 0;


class CatalogSingleton
{
    public:
        static CatalogSingleton* getInstance() {
			if (instance == 0)
				instance = new CatalogSingleton();
			return instance;
		}

    private:
        static CatalogSingleton* instance;

        CatalogSingleton(){}
        
		unordered_map<string, list<unsigned>::iterator > ma;
};

/* Null, because instance will be initialized on demand. */
CatalogSingleton* CatalogSingleton::instance = 0;


#endif // VOD_UTILS_HH_
