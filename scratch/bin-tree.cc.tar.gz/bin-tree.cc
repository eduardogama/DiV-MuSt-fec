#include "ns3/core-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/network-module.h"
#include "ns3/applications-module.h"
#include "ns3/wifi-module.h"
#include "ns3/mobility-module.h"
#include "ns3/csma-module.h"
#include "ns3/internet-module.h"
#include "ns3/dashplayer-tracer.h"
#include "ns3/node-throughput-tracer.h"
#include "ns3/ipv4-static-routing-helper.h"
#include "ns3/ipv4-list-routing-helper.h"
#include "ns3/ipv4-nix-vector-helper.h"
#include "ns3/flow-monitor-helper.h"
#include "ns3/flow-monitor-module.h"

#include "ns3/uinteger.h"
#include "ns3/netanim-module.h"

#include <map>
#include <fstream>
#include <string>
#include <sstream>
#include <ctime>

#include "dash-utils.h"
#include "vod-utils.h"
#include "vod-server.h"
#include "vod-controller.h"

#include "tree-utils.h"
#include "graph-utils.h"

using namespace ns3;
using namespace std;

NS_LOG_COMPONENT_DEFINE ("BinTree");


vector<GroupUser *> groups = NetworkSingleton::getInstance()->getGroups();

class Experiment {
    public:
        Experiment();
        ~Experiment();

        bool CreateDir(string name);
        string getDirectory();
        void setDirectory(string _dir);
    private:
        string dir;
};

Experiment::Experiment(){}
Experiment::~Experiment(){}

bool Experiment::CreateDir(string name) {
    dir = name;
    return system(string(string("mkdir -p ") + name).c_str()) != -1;
}

string Experiment::getDirectory(){
    return dir;
}

void Experiment::setDirectory(string _dir){
    dir = _dir;
}

class DashReqServer : public Application
{
	public:
		DashReqServer();
		virtual ~ DashReqServer();

		/**
		* Register this type.
		* \return The TypeId.
		*/
		static TypeId GetTypeId (void);
		void Setup (Address address, uint16_t port);

		bool ConnectionRequested (Ptr<Socket> socket, const Address& address);
		void ConnectionAccepted (Ptr<Socket> socket, const Address& address);

		void HandleIncomingData(Ptr<Socket> socket);
		void HandleReadyToTransmit(Ptr<Socket> socket, string &video);

		void ConnectionClosedNormal (Ptr<Socket> socket);
		void ConnectionClosedError (Ptr<Socket> socket);

		void DoSendRedirect();

	private:
		virtual void StartApplication (void);
		virtual void StopApplication (void);

		void ScheduleTx (void);
		void SendPacket (void);

		Ptr<Socket>     m_socket;
		Address         m_listeningAddress;
		uint32_t        m_packetSize;
		uint32_t        m_nPackets;
		DataRate        m_dataRate;
		EventId         m_sendEvent;
		bool            m_running;
		uint32_t        m_packetsSent;
        uint16_t 	    m_port; //!< Port on which we listen for incoming packets.


        map< string, Ptr<Socket> > m_clientSocket;
};

DashReqServer::DashReqServer ()
						: m_socket (0),
							m_listeningAddress (),
							m_packetSize (0),
							m_nPackets (0),
							m_dataRate (0),
							m_sendEvent (),
							m_running (false),
							m_packetsSent (0)
{
}

DashReqServer::~DashReqServer ()
{
	m_socket = 0;
}

/* static */
TypeId DashReqServer::GetTypeId (void)
{
	static TypeId tid = TypeId ("DashReqServer")
		.SetParent<Application> ()
		.SetGroupName ("Tutorial")
		.AddConstructor<DashReqServer> ()
		.AddAttribute ("ListeningAddress",
                   "The listening Address for the inbound packets",
                   AddressValue (),
                   MakeAddressAccessor (&DashReqServer::m_listeningAddress),
                   MakeAddressChecker ())
		.AddAttribute ("Port", "Port on which we listen for incoming packets (default: 1317).",
                   UintegerValue (1317),
                   MakeUintegerAccessor (&DashReqServer::m_port),
                   MakeUintegerChecker<uint16_t> ())
                   ;
	return tid;
}

void DashReqServer::Setup (Address address, uint16_t port)
{
	this->m_listeningAddress = address;
	this->m_port = port;
}

void DashReqServer::StartApplication (void)
{
	m_running = true;
	m_packetsSent = 0;
	if(m_socket == 0) {
		TypeId tid = TypeId::LookupByName ("ns3::TcpSocketFactory");

        m_socket = Socket::CreateSocket(GetNode(), tid);

        // Fatal error if socket type is not NS3_SOCK_STREAM or NS3_SOCK_SEQPACKET
        if (m_socket->GetSocketType () != Socket::NS3_SOCK_STREAM &&
        m_socket->GetSocketType () != Socket::NS3_SOCK_SEQPACKET)
        {
            fprintf(stderr,"Using BulkSend with an incompatible socket type. "
                          "BulkSend requires SOCK_STREAM or SOCK_SEQPACKET. "
                          "In other words, use TCP instead of UDP.\n");
        }

        if (Ipv4Address::IsMatchingType(m_listeningAddress) == true)
        {
            InetSocketAddress local = InetSocketAddress (Ipv4Address::ConvertFrom(m_listeningAddress), m_port);
            std::cout << "Listening on Ipv4 " << Ipv4Address::ConvertFrom(m_listeningAddress) << ":" << m_port << std::endl;
            m_socket->Bind (local);
        } else if (Ipv6Address::IsMatchingType(m_listeningAddress) == true)
        {
            Inet6SocketAddress local6 = Inet6SocketAddress (Ipv6Address::ConvertFrom(m_listeningAddress), m_port);
            std::cout << "Listening on Ipv6 " << Ipv6Address::ConvertFrom(m_listeningAddress) << std::endl;
            m_socket->Bind (local6);
        } else {
            std::cout << "Not sure what type the m_listeningaddress is... " << m_listeningAddress << std::endl;
        }
	}

	m_socket->Listen();

	// And make sure to handle requests and accepted connections
    m_socket->SetAcceptCallback(MakeCallback(&DashReqServer::ConnectionRequested, this),
        						MakeCallback(&DashReqServer::ConnectionAccepted, this));
}

void DashReqServer::StopApplication (void)
{
	m_running = false;

	if (m_sendEvent.IsRunning ()) {
		Simulator::Cancel (m_sendEvent);
	}

	if (m_socket) {
		m_socket->Close ();
	}
}

bool DashReqServer::ConnectionRequested (Ptr<Socket> socket, const Address& address)
{
    NS_LOG_FUNCTION (this << socket << address);
    NS_LOG_DEBUG (Simulator::Now () << " Socket = " << socket << " " << " Server: ConnectionRequested");

    return true;
}

void DashReqServer::ConnectionAccepted (Ptr<Socket> socket, const Address& address)
{
    NS_LOG_FUNCTION (this << socket << address);

	InetSocketAddress iaddr = InetSocketAddress::ConvertFrom (address);

	cout << "DashReqServer(" << socket << ") " << Simulator::Now ()
			  << " Successful socket creation Connection Accepted From " << iaddr.GetIpv4 ()
			  << " port: " << iaddr.GetPort ()<< endl;

	stringstream gstream;
    gstream << iaddr.GetIpv4 ();

	m_clientSocket[gstream.str()] = socket;

    socket->SetRecvCallback (MakeCallback (&DashReqServer::HandleIncomingData, this));


    socket->SetCloseCallbacks(MakeCallback (&DashReqServer::ConnectionClosedNormal, this),
                              MakeCallback (&DashReqServer::ConnectionClosedError,  this));
}

void DashReqServer::HandleIncomingData(Ptr<Socket> socket)
{
    Ptr<Packet> packet;
    Address from;

    packet = socket->RecvFrom (from);

    if (!(packet)) {
        return;
    }

	uint8_t *buffer = new uint8_t[packet->GetSize ()];
	packet->CopyData(buffer, packet->GetSize ());
	string str_s = string(buffer, buffer+packet->GetSize());

	cout << "================================================================================\n";
    fprintf(stderr, "DashReqServer : HandleIncomingData - connection with DashReqServer received %s\n", str_s.c_str());

    HandleReadyToTransmit(socket, str_s);
}

void DashReqServer::HandleReadyToTransmit(Ptr<Socket> socket, std::string &requestString)
{
	cout << "DashReqServer " << Simulator::Now () << " Socket HandleReadyToTransmit (DashReqServer Class) From " << socket << endl;
	cout << "Server Ip = " << requestString << endl;

    uint8_t* buffer = (uint8_t*)requestString.c_str();

	Ptr<Packet> pkt = Create<Packet> (buffer, requestString.length());


    // call to the trace sinks before the packet is actually sent, so that tags added to the packet can be sent as well
//    m_txTrace (pkt);
    socket->Send (pkt);
}

void DashReqServer::DoSendRedirect()
{
	vector<GroupUser *> &groups = NetworkSingleton::getInstance()->getGroups();
	for (auto& group : groups) {
		for (auto& user : group->getUsers()) {

			cout << "User Ip = "  << user->getIp() << " Server = " << group->getServerIp() << " user size = " << group->getUsers().size() << endl;
			string serverIp = group->getServerIp();

			if (m_clientSocket[user->getIp()] == 0) {
				continue;
			}

			HandleReadyToTransmit(m_clientSocket[user->getIp()], serverIp);
		}
	}
}

void DashReqServer::ConnectionClosedNormal (Ptr<Socket> socket)
{}

void DashReqServer::ConnectionClosedError (Ptr<Socket> socket)
{}

void DashReqServer::SendPacket (void)
{
	Ptr<Packet> packet = Create<Packet> (m_packetSize);
	m_socket->Send (packet);

	if (++m_packetsSent < m_nPackets) {
		ScheduleTx ();
	}
}

void DashReqServer::ScheduleTx (void)
{
	if (m_running) {
		Time tNext (Seconds (m_packetSize * 8 / static_cast<double> (m_dataRate.GetBitRate ())));
		m_sendEvent = Simulator::Schedule (tNext, &DashReqServer::SendPacket, this);
	}
}


string GetCurrentWorkingDir(void)
{
	char buff[250];
	getcwd( buff, 250 );
	string current_working_dir(buff);
	return current_working_dir;
}


double averageArrival = 5;
double lamda = 1 / averageArrival;
std::mt19937 rng (0);
std::vector<double> sum_probs;

std::exponential_distribution<double> poi (lamda);
std::uniform_real_distribution<double> unif(0, 1);

double sumArrivalTimes = 0;
double newArrivalTime;

double poisson()
{
	newArrivalTime = poi.operator() (rng);// generates the next random number in the distribution
	sumArrivalTimes = sumArrivalTimes + newArrivalTime;
	std::cout << "newArrivalTime: " << newArrivalTime  << ", sumArrivalTimes: " << sumArrivalTimes << std::endl;
	if (sumArrivalTimes < 3.6) {
		sumArrivalTimes = 3.6;
	}
	return sumArrivalTimes;
}

int zipf(double alpha, int n)
{
	static int first = true;      // Static first time flag
	static double c = 0;          // Normalization constant
	double z;                     // Uniform random number (0 < z < 1)
	int    zipf_value;            // Computed exponential value to be returned
	int    i;                     // Loop counter
	int    low, high, mid;        // Binary-search bounds

	// Compute normalization constant on first call only
	if (first == true)
	{
		sum_probs.reserve(n+1); // Pre-calculated sum of probabilities
		sum_probs.resize(n+1);
		for (i = 1; i <= n; i++)
			c = c + (1.0 / pow((double) i, alpha));
		c = 1.0 / c;

		//sum_probs = malloc((n+1)*sizeof(*sum_probs));
		sum_probs[0] = 0;
		for (i = 1; i <= n; i++) {
			sum_probs[i] = sum_probs[i-1] + c / pow((double) i, alpha);
		}
		first = false;
	}

	// Pull a uniform random number (0 < z < 1)
	do {
		z = unif.operator()(rng);
	} while ((z == 0) || (z == 1));

	//for (i=0; i<=n; i++)
	//{
	//  std::cout << "sum_probs:  " << sum_probs[i] << std::endl;
	//}
	//std::cout << "z:  " << z << std::endl;
	// Map z to the value
	low = 1; high = n;
	do {
		mid = floor((low+high)/2);
		if (sum_probs[mid] >= z && sum_probs[mid-1] < z) {
			zipf_value = mid;
			break;
		} else if (sum_probs[mid] >= z) {
			high = mid-1;
		} else {
			low = mid+1;
		}
	} while (low <= high);
	std::cout << "ZIPF:  " << zipf_value << std::endl;
	// Assert that zipf_value is between 1 and N
	assert((zipf_value >=1) && (zipf_value <= n));

	return (zipf_value);
}

void ExecutionFlow(int userId, unsigned int src, Ptr<DashReqServer> &app)
{
	int cont = zipf(0.7, 100);
	int dest = 7;

	SetupRequestRoutingEntry(userId, cont, src, dest); //vod-controller.h

	if (NetworkSingleton::getInstance()->DoSendRedirect) {
		app->DoSendRedirect();

		NetworkSingleton::getInstance()->DoSendRedirect = false;

		printGroups();

		getchar();
	}
}

int main (int argc, char *argv[])
{
	string scenarioFiles = GetCurrentWorkingDir() + "/../content/scenario";
	string DashTraceFile = "report.csv";
	string ServerThroughputTraceFile = "server_throughput.csv";
	string RepresentationType = "netflix";


	CommandLine cmd;

	//default parameters
	cmd.AddValue("DashTraceFile", "Filename of the DASH traces", DashTraceFile);
	cmd.AddValue("ServerThroughputTraceFile", "Filename of the server throughput traces", ServerThroughputTraceFile);
	cmd.AddValue("RepresentationType", "Input representation type name", RepresentationType);
    cmd.AddValue("stopTime", "The time when the clients will stop requesting segments", NetworkSingleton::getInstance()->stopTime);
    cmd.AddValue("AdaptationLogicToUse", "Adaptation Logic to Use.", NetworkSingleton::getInstance()->AdaptationLogicToUse);
    cmd.AddValue("seed", "Seed experiment.", NetworkSingleton::getInstance()->seed);
	cmd.Parse (argc, argv);

	vector<_Link *> linksData;
	vector<_Node *> nodesData;

	vector<Edge> edges;

	io_read_topology(scenarioFiles + "/tree_l3_link_2", scenarioFiles + "/tree_l3_nodes", linksData, nodesData);


	NodeContainer nodes;
	nodes.Create( nodesData.size() );

	for (unsigned int i = 0; i < nodesData.size(); i += 1) {
		std::ostringstream ss;
		ss << nodesData.at(i)->getId();
		Names::Add(nodesData.at(i)->getType() + ss.str(), nodes.Get( nodesData.at(i)->getId() ));
	}

	// Later we add IP Addresses
	NS_LOG_INFO("Assign IP Addresses.");
	InternetStackHelper internet;

	fprintf(stderr, "Installing Internet Stack\n");
	// Now add ip/tcp stack to all nodes.
	internet.Install(nodes);

		// create p2p links
	vector<NetDeviceContainer> netDevices;
	Ipv4AddressHelper address;
	address.SetBase ("10.0.0.0", "255.255.255.0");
	PointToPointHelper p2p;

	for (unsigned int i = 0; i < linksData.size(); i += 1) {
		p2p.SetDeviceAttribute("DataRate", DataRateValue( linksData.at(i)->getRate() )); // Mbit/s

		// And then install devices and channels connecting our topology
		NetDeviceContainer deviceContainer;
		deviceContainer = p2p.Install(nodes.Get(linksData.at(i)->getSrcId()), nodes.Get(linksData.at(i)->getDstId()));

		address.Assign(deviceContainer);
		address.NewNetwork();
		netDevices.push_back(deviceContainer);

		edges.push_back({linksData.at(i)->getSrcId(), linksData.at(i)->getDstId(), linksData.at(i)->getRate()});

		Ptr<Node> nsrc = nodes.Get(linksData.at(i)->getSrcId());
		Ptr<Ipv4> ipv4src = nsrc->GetObject<Ipv4>();

		Ptr<Node> ndest = nodes.Get(linksData.at(i)->getDstId());
		Ptr<Ipv4> ipv4dest = ndest->GetObject<Ipv4>();

		int32_t int_prev = -1;
		for (uint32_t l = 1; l < ipv4src->GetNInterfaces(); l++) {
			for (uint32_t l1 = 1; l1 < ipv4dest->GetNInterfaces(); l1++) {
				int_prev = ipv4dest->GetInterfaceForPrefix(ipv4src->GetAddress(l, 0).GetLocal(), ipv4src->GetAddress(l, 0).GetMask());
				if (int_prev != -1)
					break;
			}

			string ipsrc = Ipv4AddressToString(ipv4src->GetAddress(l, 0).GetLocal());

			if (int_prev != -1 && cluster.find(ipsrc) == cluster.end()) {
				cluster.insert(make_pair(ipsrc, ClusterNode()));

				cluster[ipsrc].setCapacity(linksData.at(i)->getRate());
				cluster[ipsrc].setTargetCapacity(linksData.at(i)->getRate());
				cluster[ipsrc].setSrcId(linksData.at(i)->getSrcId());
				cluster[ipsrc].setDstId(linksData.at(i)->getDstId());
				cluster[ipsrc].ipv4src = ipv4src;
				cluster[ipsrc].ipv4addr = l;

				break;
			}
		}
	}

	Graph graph(edges, nodes.GetN());
	graph.printGraph();
	NetworkSingleton::getInstance()->setGraph(&graph);
	NetworkSingleton::getInstance()->setNodes(&nodes);

	//Store IP adresses
	std::string addr_file = "addresses";
	ofstream out_addr_file(addr_file.c_str());
	for (unsigned int i = 0; i < nodes.GetN(); i++) {
		Ptr<Node> n = nodes.Get(i);
		Ptr<Ipv4> ipv4 = n->GetObject<Ipv4>();
		for (uint32_t l = 1; l < ipv4->GetNInterfaces(); l++) {
			out_addr_file << i <<  " " << ipv4->GetAddress(l, 0).GetLocal() << endl;
		}
	}
	out_addr_file.flush();
	out_addr_file.close();


	// %%%%%%%%%%%% Set up the DASH server

	stringstream gstream;

    Ptr<Node> n = nodes.Get (7);
    Ptr<Ipv4> ipv4 = n->GetObject<Ipv4> ();
    gstream << ipv4->GetAddress(1,0).GetLocal ();

    std::cout << "CDN Server = " << gstream.str() << std::endl;
	//=======================================================================================

    NS_LOG_INFO ("Create Applications.");
    NetworkSingleton::getInstance()->srv_ip = gstream.str ();
    gstream.str ("");

    string representationStrings = GetCurrentWorkingDir() + "/../../dataset/netflix_vid1.csv";
	fprintf(stderr, "representations = %s\n", representationStrings.c_str ());

	DASHServerHelper server (Ipv4Address::GetAny (), 80,  NetworkSingleton::getInstance()->srv_ip,
		                   "/content/mpds/", representationStrings, "/content/segments/");

	ApplicationContainer serverApps = server.Install(nodes.Get(7));
	serverApps.Start (Seconds(0.0));
	serverApps.Stop (Seconds(NetworkSingleton::getInstance()->stopTime));

	Ptr<DashReqServer> app = CreateObject<DashReqServer> ();
	app->Setup(Ipv4Address::GetAny (), 1317);
	nodes.Get(7)->AddApplication(app);
	app->SetStartTime(Seconds(0.0));
	app->SetStopTime(Seconds(NetworkSingleton::getInstance()->stopTime));


	// %%%%%%%%%%%% Set up the Mobility Position
	MobilityHelper mobility;
	// setup the grid itself: objects are laid out
	// started from (-100,-100) with 20 objects per row,
	// the x interval between each object is 5 meters
	// and the y interval between each object is 20 meters
	mobility.SetPositionAllocator ("ns3::GridPositionAllocator",
		                          "MinX", DoubleValue (-10.0),
		                          "MinY", DoubleValue (-10.0),
		                          "DeltaX", DoubleValue (20.0),
		                          "DeltaY", DoubleValue (20.0),
		                          "GridWidth", UintegerValue (20),
		                          "LayoutType", StringValue ("RowFirst"));
	// each object will be attached a static position.
	// i.e., once set by the "position allocator", the
	// position will never change.
	mobility.SetMobilityModel ("ns3::ConstantPositionMobilityModel");



	YansWifiChannelHelper channel = YansWifiChannelHelper::Default();
    YansWifiPhyHelper phy = YansWifiPhyHelper::Default();

	unsigned n_ap = 0, n_clients = 5;
	NodeContainer clients;

	Ptr<ListPositionAllocator> positionAlloc = CreateObject <ListPositionAllocator>();

	for (unsigned int i = 0; i < nodesData.size(); i += 1) {
		std::size_t found = Names::FindName( nodes.Get(nodesData.at(i)->getId()) ).find("ap");
		if (found != std::string::npos) {
			mobility.Install(nodes.Get(nodesData.at(i)->getId()));

			Ptr<MobilityModel> mob = (nodes.Get(nodesData.at(i)->getId()))->GetObject<MobilityModel>();

		    int aux = 360/n_clients;
			double x = mob->GetPosition().x, y = mob->GetPosition().y;
			for (size_t i = 0; i < 360; i += aux) {
				double cosseno = cos(i);
				double seno    = sin(i);
				positionAlloc->Add(Vector(5*cosseno + x , 5*seno + y, 0));
			}

			NodeContainer c;
			c.Create(n_clients);
			clients.Add(c);

			internet.Install(c);

			WifiHelper wifi;
			WifiMacHelper mac;
		    phy.SetChannel(channel.Create());

			std::ostringstream ss;
			ss << "ns-3-ssid-" << ++n_ap;
		    Ssid ssid = Ssid(ss.str());


			wifi.SetRemoteStationManager("ns3::AarfWifiManager");
			wifi.SetStandard (WIFI_PHY_STANDARD_80211g);

			NodeContainer ap = nodes.Get(nodesData.at(i)->getId());
			mac.SetType("ns3::ApWifiMac", "Ssid", SsidValue (ssid));
			NetDeviceContainer ap_dev =  wifi.Install(phy, mac, ap);

			mac.SetType("ns3::StaWifiMac", "Ssid", SsidValue (ssid), "ActiveProbing", BooleanValue (false));
			NetDeviceContainer sta_dev = wifi.Install(phy, mac, c);

			address.Assign(ap_dev);
			address.Assign(sta_dev);
			address.NewNetwork();
		}
	}

    positionAlloc->Add(Vector(0, 0, 0));   // Ap 1
    positionAlloc->Add(Vector(30, 0, 0));   // Ap 2
    positionAlloc->Add(Vector(15, 15, 0)); // node2
    positionAlloc->Add(Vector(15, 30, 0)); // node3

	mobility.SetPositionAllocator(positionAlloc);
	mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
	mobility.Install(clients);

	mobility.Install(nodes.Get(1));
	mobility.Install(nodes.Get(2));
	mobility.Install(nodes.Get(0));
	mobility.Install(nodes.Get(7));

	NetworkSingleton::getInstance()->setClients(&clients);

	// %%%%%%%%%%%% End Set up the Mobility Position

	Ipv4GlobalRoutingHelper::PopulateRoutingTables();

	// %%%%%%%%%%%% Set up the DASH Clients

	unsigned aux1 = 0;
	SeedManager::SetRun(time(0));
	Ptr<UniformRandomVariable> uv = CreateObject<UniformRandomVariable> ();
	for (unsigned int ap_i = 0; ap_i < nodesData.size(); ap_i += 1)
	{
		std::size_t found = Names::FindName( nodes.Get(nodesData.at(ap_i)->getId()) ).find("ap");
		if (found != std::string::npos)
		{
			for (unsigned int user = 0; user < n_clients; user++)
			{
				NetworkSingleton::getInstance()->rdm += uv->GetValue();
				NetworkSingleton::getInstance()->UserId = user + aux1 * n_clients;

				int UserId = NetworkSingleton::getInstance()->UserId;
				int screenWidth = 1920;
				int screenHeight = 1080;

				std::stringstream mpd_baseurl;
				mpd_baseurl << "http://" << NetworkSingleton::getInstance()->srv_ip << "/content/mpds/";

				std::stringstream ssMPDURL;
				ssMPDURL << mpd_baseurl.str() << "vid" << 1 << ".mpd.gz";

				DASHHttpClientHelper player (ssMPDURL.str ());
				player.SetAttribute("AdaptationLogic", StringValue(NetworkSingleton::getInstance()->AdaptationLogicToUse));
				player.SetAttribute("StartUpDelay", StringValue("4"));
				player.SetAttribute("ScreenWidth", UintegerValue(screenWidth));
				player.SetAttribute("ScreenHeight", UintegerValue(screenHeight));
				player.SetAttribute("UserId", UintegerValue(NetworkSingleton::getInstance()->UserId));
				player.SetAttribute("AllowDownscale", BooleanValue(true));
				player.SetAttribute("AllowUpscale", BooleanValue(true));
				player.SetAttribute("MaxBufferedSeconds", StringValue("60"));

				ApplicationContainer clientApps;
				clientApps = player.Install(NetworkSingleton::getInstance()->clients->Get(UserId));

				clientApps.Start(Seconds(0.5 + NetworkSingleton::getInstance()->rdm));
				clientApps.Stop(Seconds (NetworkSingleton::getInstance()->stopTime));

				Simulator::Schedule(Seconds(NetworkSingleton::getInstance()->rdm + 0.25), ExecutionFlow, user + aux1*n_clients, ap_i, app);
			}
			aux1++;
		}
	}

	// %%%%%%%%%%%% sort out the simulation
	Experiment exp;

    gstream << "../bin-tree";
    if (!exp.CreateDir(gstream.str())) {
        printf("Error creating directory!\n");
        exit(1);
    }
    gstream.str("");


    gstream << exp.getDirectory() << "/output-dash-" << NetworkSingleton::getInstance()->seed << ".csv";
    DASHPlayerTracer::InstallAll(gstream.str());
    gstream.str("");

    gstream << exp.getDirectory() << "/throughput-" << NetworkSingleton::getInstance()->seed << ".csv";
    NodeThroughputTracer::InstallAll(gstream.str());
    gstream.str("");

	AnimationInterface anim(exp.getDirectory() + std::string("/topology.netanim"));

	Simulator::Stop(Seconds(NetworkSingleton::getInstance()->stopTime));
	Simulator::Run();
	Simulator::Destroy();

	DASHPlayerTracer::Destroy();


	return 0;
}
