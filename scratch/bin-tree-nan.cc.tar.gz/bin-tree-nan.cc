#include "ns3/core-module.h"
#include "ns3/applications-module.h"
#include "ns3/internet-module.h"
#include "ns3/mobility-module.h"
#include "ns3/wifi-module.h"
#include "ns3/netanim-module.h"


#include <string>

#include "utils.h"
#include "group-user.h"


using namespace ns3;
using namespace std;

NS_LOG_COMPONENT_DEFINE ("BinTreeTwo");


typedef struct {
	int actualNode;
	int nextNode;
	string ipv4;
} Interface;

class DashController : public Application
{
	public:
		DashController();
		virtual ~DashController();

		/**
		* Register this type.
		* \return The TypeId.
		*/
		static TypeId GetTypeId (void);

		void Setup (Address address, uint16_t port);
		void SetNetworkTopology (NetworkTopology* network);

		bool ReadTopology (string linksFile, string nodesFile);

		void FindCommonGroups (vector<int>& free_groups, vector<int>& g_i, int actualNode, int nextNode);

		bool canAlloc (vector<int>& g_i, int actualNode, int nextNode);

		void ISOA (vector<int> &free_groups, vector<int> &g);
		void SetupRequestRoutingEntry (unsigned int userId, int cont, unsigned src, unsigned dest);

		bool SendRedirect ();
		void setSendRedirect (bool sendRedirect);
		void DoSendRedirect ();
		void BuildApplication ();

		void printGroups ()
		{
			for (auto &group : groups) {
				std::cout << "GROUP IP " << group->getId() << std::endl;
				for (auto &user : group->getUsers()) {
					cout << "-> User(" << user->getId() << ") : " << user->getIp() << " Server(" << group->getRoute().getActualStep() << ")" << endl;
				}
			}
		}

		bool ConnectionRequested (Ptr<Socket> socket, const Address& address);
		void ConnectionAccepted (Ptr<Socket> socket, const Address& address);

		void HandleIncomingData (Ptr<Socket> socket);
		void HandleReadyToTransmit (Ptr<Socket> socket, string &video);

		void ConnectionClosedNormal (Ptr<Socket> socket);
		void ConnectionClosedError (Ptr<Socket> socket);

		void setServerIp (string serverIp) {this->m_serverIp = serverIp;}
		string getServerIp () {return this->m_serverIp;}

		string getInterfaceNode (unsigned actualNode, unsigned nextNode);

		void addCdnServer (string server);

		vector<string> &getClientAgg() {return this->clients_agg;}

		void ReSendRedirectAgg();
	private:
		virtual void StartApplication (void);
		virtual void StopApplication (void);

		GroupUser* AddUserInGroup (unsigned int userId, int cont, unsigned src, unsigned dest);

		bool sendRedirect;

		Ptr<Socket>     m_socket;
		Address         m_listeningAddress;
		uint32_t        m_packetSize;
		uint32_t        m_nPackets;
		DataRate        m_dataRate;
		EventId         m_sendEvent;
		bool            m_running;
		uint32_t        m_packetsSent;
		uint16_t 	    	m_port; //!< Port on which we listen for incoming packets.
		string 					m_serverIp;

		vector<GroupUser *> groups;

		NetworkTopology *network;

    map< string, Ptr<Socket> > m_clientSocket;

    vector<Interface> m_interfaces;
    vector<Interface> m_wireless_interfaces;
    vector<string> cdn_srvs;
    vector<string> clients_agg;
};

DashController::DashController () :
							sendRedirect (false),
							m_running (false),
							m_socket (0),
							m_listeningAddress (),
							m_packetSize (0),
							m_nPackets (0),
							m_dataRate (0),
							m_sendEvent ()
{
}

DashController::~DashController ()
{
}

TypeId DashController::GetTypeId (void)
{
	static TypeId tid = TypeId ("ns3::DashController")
		.SetParent<Application> ()
		.SetGroupName ("Applications")
		.AddConstructor<DashController> ()
		.AddAttribute ("ListeningAddress",
                   "The listening Address for the inbound packets",
                   AddressValue (),
                   MakeAddressAccessor (&DashController::m_listeningAddress),
                   MakeAddressChecker ())
		.AddAttribute ("Port", "Port on which we listen for incoming packets (default: 1317).",
                   UintegerValue (1317),
                   MakeUintegerAccessor (&DashController::m_port),
                   MakeUintegerChecker<uint16_t> ())
                   ;
	return tid;
}

void DashController::StartApplication (void)
{
	m_running = true;
	m_packetsSent = 0;
	if(m_socket == 0) {
		TypeId tid = TypeId::LookupByName ("ns3::TcpSocketFactory");

        m_socket = Socket::CreateSocket (GetNode(), tid);

        // Fatal error if socket type is not NS3_SOCK_STREAM or NS3_SOCK_SEQPACKET
        if (m_socket->GetSocketType () != Socket::NS3_SOCK_STREAM &&
				m_socket->GetSocketType () != Socket::NS3_SOCK_SEQPACKET)
        {
            fprintf (stderr,"Using BulkSend with an incompatible socket type. "
	                          "BulkSend requires SOCK_STREAM or SOCK_SEQPACKET. "
	                          "In other words, use TCP instead of UDP.\n");
        }

        if (Ipv4Address::IsMatchingType (m_listeningAddress) == true)
        {
            InetSocketAddress local = InetSocketAddress (Ipv4Address::ConvertFrom (m_listeningAddress), m_port);
            cout << "Listening on Ipv4 " << Ipv4Address::ConvertFrom (m_listeningAddress) << ":" << m_port << endl;
            m_socket->Bind (local);
        } else if (Ipv6Address::IsMatchingType (m_listeningAddress) == true)
        {
            Inet6SocketAddress local6 = Inet6SocketAddress (Ipv6Address::ConvertFrom (m_listeningAddress), m_port);
            cout << "Listening on Ipv6 " << Ipv6Address::ConvertFrom (m_listeningAddress) << endl;
            m_socket->Bind (local6);
        } else {
            cout << "Not sure what type the m_listeningaddress is... " << m_listeningAddress << endl;
        }
	}

	m_socket->Listen ();

	// And make sure to handle requests and accepted connections
    m_socket->SetAcceptCallback (MakeCallback(&DashController::ConnectionRequested, this),
        						MakeCallback(&DashController::ConnectionAccepted, this));
}

void DashController::StopApplication (void)
{
}

void DashController::Setup (Address address, uint16_t port)
{
	this->m_listeningAddress = address;
	this->m_port = port;

	for (auto& link : network->getLinks()) {
		Ptr<Node> nsrc = network->getNodeContainers()->Get(link->getSrcId());
		Ptr<Ipv4> ipv4src = nsrc->GetObject<Ipv4>();

		Ptr<Node> ndest = network->getNodeContainers()->Get(link->getDstId());
		Ptr<Ipv4> ipv4dest = ndest->GetObject<Ipv4> ();

		int32_t int_prev = -1;
		for (uint32_t l = 1; l < ipv4src->GetNInterfaces (); l++) {
			for (uint32_t l1 = 1; l1 < ipv4dest->GetNInterfaces (); l1++) {
				int_prev = ipv4dest->GetInterfaceForPrefix (ipv4src->GetAddress(l, 0).GetLocal(), ipv4src->GetAddress(l, 0).GetMask());
				if (int_prev != -1) {
					break;
				}
			}

			string ipsrc = Ipv4AddressToString (ipv4src->GetAddress(l, 0).GetLocal());

			if (int_prev != -1) {
				m_interfaces.push_back({link->getSrcId(), link->getDstId(), ipsrc});
			}
		}
	}

	// Add wireless interface from ap nodes ===========================================
	for (unsigned int i = 0; i < network->getNodes().size(); i += 1) {
		Ptr<Node> node = network->getNodeContainers()->Get(network->getNodes().at(i)->getId());

		size_t found = Names::FindName(node).find("ap");
		if (found != string::npos) {
			Ptr<Ipv4> ipv4 = node->GetObject<Ipv4>();
			string ipsrc = Ipv4AddressToString(ipv4->GetAddress(2, 0).GetLocal());

			m_interfaces.push_back({network->getNodes().at(i)->getId(), network->getNodes().size(), ipsrc});
		}
	}

	for (auto& interface : m_interfaces) {
		cout << "-> (" << interface.actualNode << "," << interface.nextNode << ") -> " << interface.ipv4 << endl;
	}
}

void DashController::SetNetworkTopology (NetworkTopology *network)
{
	this->network = network;
}

bool DashController::ConnectionRequested (Ptr<Socket> socket, const Address& address)
{
    NS_LOG_FUNCTION (this << socket << address);
    NS_LOG_DEBUG (Simulator::Now () << " Socket = " << socket << " " << " Server: ConnectionRequested");

    return true;
}

void DashController::ConnectionAccepted (Ptr<Socket> socket, const Address& address)
{
    NS_LOG_FUNCTION (this << socket << address);

	InetSocketAddress iaddr = InetSocketAddress::ConvertFrom (address);

	cout << "DashReqServer(" << socket << ") " << Simulator::Now ()
			  << " Successful socket creation Connection Accepted From " << iaddr.GetIpv4 ()
			  << " port: " << iaddr.GetPort ()<< endl;

	stringstream gstream;
    gstream << iaddr.GetIpv4 ();

	m_clientSocket[gstream.str()] = socket;

    socket->SetRecvCallback (MakeCallback (&DashController::HandleIncomingData, this));


    socket->SetCloseCallbacks(MakeCallback (&DashController::ConnectionClosedNormal, this),
                              MakeCallback (&DashController::ConnectionClosedError,  this));
}

void DashController::HandleIncomingData(Ptr<Socket> socket)
{
    Ptr<Packet> packet;
    Address from;

    packet = socket->RecvFrom (from);

    if (!(packet)) {
        return;
    }

	uint8_t *buffer = new uint8_t[packet->GetSize ()];
	packet->CopyData(buffer, packet->GetSize ());
	string str_s = string(buffer, buffer+packet->GetSize());

	cout << "================================================================================\n";
    fprintf(stderr, "DashController : HandleIncomingData - connection with DashController received %s\n", str_s.c_str());

    HandleReadyToTransmit(socket, str_s);
}

void DashController::ConnectionClosedNormal (Ptr<Socket> socket)
{}

void DashController::ConnectionClosedError (Ptr<Socket> socket)
{}

string DashController::getInterfaceNode(unsigned actualNode, unsigned nextNode)
{
	for (auto& interface : m_interfaces) {
		if (interface.actualNode == actualNode && interface.nextNode == nextNode) {
			cout << "-> getInterface() : " << interface.ipv4 << "\n";
			return interface.ipv4;
		}
	}

	return "";
}

void DashController::addCdnServer(string server)
{
	this->cdn_srvs.push_back(server);
}

bool DashController::SendRedirect()
{
	return this->sendRedirect;
}

void DashController::setSendRedirect(bool sendRedirect)
{
	this->sendRedirect = sendRedirect;
}

void ReSendRedirectAgg(Ptr<DashController> &controller)
{
	controller->ReSendRedirectAgg();

	if (controller->getClientAgg().size() > 0) {
		Simulator::Schedule(Simulator::Now() + Seconds(0.25), ReSendRedirectAgg, controller);
	}
}

void DashController::ReSendRedirectAgg()
{
	for (int i = 0; i < clients_agg.size(); i++) {

		if (m_clientSocket[clients_agg[i]] == 0) {
			continue;
		}

		HandleReadyToTransmit(m_clientSocket[clients_agg[i]], clients_agg[i]);

		// erase the ith element
	    clients_agg.erase (clients_agg.begin()+i);
	}
}

void DashController::DoSendRedirect()
{
	for (auto& group : groups) {
		for (auto& user : group->getUsers()) {
			cout << "[DashController] User Ip = "  << user->getIp() << " Server = " << group->getServerIp()
				 << " user size = " << group->getUsers().size() << endl;
			string serverIp = group->getServerIp();

			if (m_clientSocket[user->getIp()] == 0) {
				clients_agg.push_back(user->getIp());
				continue;
			}

			HandleReadyToTransmit(m_clientSocket[user->getIp()], serverIp);
		}
	}
}

void DashController::BuildApplication() {
	int srv;
	string str_srv;

	for (auto& group : groups) {

		bool findedServer = false;
		for (auto& srv_node : cdn_srvs) {
			if (srv_node != group->getServerIp()) {
				cdn_srvs.push_back(group->getServerIp());
				findedServer = true;
				break;
			}
		}

		if (findedServer) {
			str_srv = group->getServerIp();
		}
	}

	for (auto& interface : m_interfaces)
	{
		if (str_srv == interface.ipv4) {
			srv = interface.actualNode;
		}
	}

	string representationStrings = GetCurrentWorkingDir() + "/../../dataset/netflix_vid1.csv";
	fprintf(stderr, "representations = %s\n", representationStrings.c_str ());

	DASHServerHelper server (Ipv4Address::GetAny (), 80, str_srv,
		                   "/content/mpds/", representationStrings, "/content/segments/");

	ApplicationContainer serverApps = server.Install(network->getNodeContainers()->Get(srv));
	serverApps.Start (Simulator::Now ());
	serverApps.Stop (Seconds(6000));
}

void DashController::HandleReadyToTransmit(Ptr<Socket> socket, string &requestString)
{
//	cout << "DashController " << Simulator::Now () << " Socket HandleReadyToTransmit (DashController Class) From "
//		 << socket << endl << "Server Ip = " << requestString << endl;
  uint8_t* buffer = (uint8_t*)requestString.c_str();
	Ptr<Packet> pkt = Create<Packet> (buffer, requestString.length());

  socket->Send (pkt);
}

void DashController::FindCommonGroups(vector<int>& free_groups, vector<int>& g_i, int actualNode, int nextNode)
{
	for (unsigned i = 0; i < groups.size(); i++) {
		if (!free_groups[i]) {
			continue;
		}

		Path path = groups[i]->getRoute();
		path.goStart();
		while (!path.isEndPath()) {

			if (path.getActualStep() == actualNode
					&& path.getNextStep() == nextNode) {
				g_i.push_back(i);
			}

			path.goAhead();
		}
	}
}

bool DashController::canAlloc(vector<int>& g_i, int actualNode, int nextNode)
{
	int sum = 0;
	for (auto& i : g_i) {
		sum += groups[i]->getUsers().size() * 5800000;
	}

	_Link *link = NULL;
	for (auto &_link: network->getLinks())
	{
		if (_link->getSrcId() == actualNode
				&& _link->getDstId() == nextNode) {
			link = _link;
			break;
		}
	}

	if (link == NULL) {
		return false;
	}

	// return (sum + network->CapacityLink(actualNode, nextNode)) <= link->getRate();
	return sum <= link->getRate();
}

void DashController::ISOA(vector<int> &free_groups, vector<int> &g)
{
	for (unsigned int i = 0; i < free_groups.size(); i += 1) {
		if (!free_groups[i])
			continue;

		int actualNode = groups[i]->getRoute().getActualStep();
		int nextNode   = groups[i]->getRoute().getNextStep();

		vector<int> g_i;
		DashController::FindCommonGroups(free_groups, g_i, actualNode, nextNode);

		cout << "ISOA n(G_i)=" << g_i.size() << " ActualNode=" << groups[i]->getRoute().getActualStep()
			   << " -> " << getInterfaceNode(actualNode, nextNode) << "\n";

		if ((g_i.size() > 0 & DashController::canAlloc(g_i, actualNode, nextNode))) {
			for (auto& i : g_i) {
				free_groups[i] = 0;

				string new_serverIp = getInterfaceNode(actualNode, nextNode);
				groups[i]->setActualNode(actualNode);
				groups[i]->setServerIp(new_serverIp);

				for (unsigned j = 0; j < groups[i]->getUsers().size(); j++) {
					network->allocStream(groups[i]->getRoute().getActualStep(), groups[i]->getRoute().getNextStep());
				}
			}
		} else if (groups[i]->getRoute().isEndPath()) {

			Ptr<Node> node = network->getNodeContainers()->Get(actualNode);
			size_t found = Names::FindName(node).find("ap");
			if (found != string::npos) {
				cout << ":=> " << actualNode << " " << network->getNodes().at(actualNode)->getId() << endl;
				Ptr<Ipv4> ipv4 = node->GetObject<Ipv4>();
				string new_serverIp = Ipv4AddressToString(ipv4->GetAddress(2, 0).GetLocal());

				groups[i]->setActualNode(actualNode);
				groups[i]->setServerIp(new_serverIp);

				// getchar();
			}

		} else {
			groups[i]->getRoute().goAhead();
			ISOA(free_groups, g_i);
		}
	}
}

void DashController::SetupRequestRoutingEntry(unsigned int userId, int cont, unsigned src, unsigned dest)
{
	GroupUser *g_i = DashController::AddUserInGroup(userId, cont, src, dest);

	int actualNode = g_i->getRoute().getActualStep();
	int nextNode   = g_i->getRoute().getNextStep();

	if (network->canAlloc(actualNode, nextNode)) {
		network->allocStream(actualNode, nextNode);
	} else {
		cout << "CONEXAO (" << actualNode << "," << nextNode << ") NAO ALLOCADA "
			 	 << network->CapacityLink(actualNode, nextNode) << endl;

		network->ResetCapacityLink(actualNode, nextNode);

		vector<int> free_groups(groups.size(), 1);
		vector<int> g;
		FindCommonGroups(free_groups, g, actualNode, nextNode);

		for (unsigned int i = 0; i < free_groups.size(); i += 1) {
			bool find = true;
			for (unsigned int j = 0; j < g.size(); j += 1) {
				if (g[j] == i) {
					find = false;
				}
			}
			if (find) {
				free_groups[i] = 0;
				cout << i << " " << groups[i]->getServerIp() << endl;
			}
		}
		// getchar();

		DashController::ISOA(free_groups, g);
		setSendRedirect(true);
	}
}

GroupUser* DashController::AddUserInGroup(unsigned userId, int cont, unsigned src, unsigned dest)
{
	network->SearchRoute(dest, src);

	Ptr<Node> n = network->getClientContainers()->Get(userId);
	Ptr<Ipv4> ipv4src = n->GetObject<Ipv4>();

	string str_ipv4src = Ipv4AddressToString(ipv4src->GetAddress(1,0).GetLocal());
	string str_ipv4bst = Ipv4AddressToString(ipv4src->GetAddress(1,0).GetBroadcast());

	cout << "==========================================================================\n"
    	 << "Starting Application client (" << userId << ") " << str_ipv4src << ", "
		 	 << " Broadcast = " << str_ipv4bst << endl;

	EndUser *new_user = new EndUser(userId, str_ipv4src, cont);

	vector<string> str_addr = str_split(str_ipv4src, ".");
  bool insert_group = false;
  for (auto& group : groups) {
    vector<string> group_addr = str_split(group->getId(), ".");

		bool same_group = true;
		for (unsigned i = 0; i < str_addr.size()-1; i++) {
			if (group_addr[i] != str_addr[i]) {
				same_group = false;
				break;
			}
		}

		if (same_group /*and cont == it->getContent()*/) {
    	group->addUser(new_user);
			return group;
		}
  }

  if (!insert_group) {
		groups.push_back(new GroupUser(str_ipv4bst, m_serverIp, src, network->getRoute(), new_user));
	}

	return groups[groups.size() - 1];
}

void Run(int userId, unsigned src, unsigned dst, Ptr<DashController> &controller)
{
	int cont = zipf(0.7, 100);

	controller->SetupRequestRoutingEntry(userId, cont, src, dst); //vod-controller.h

	if (controller->SendRedirect()) {
		controller->DoSendRedirect();

		controller->BuildApplication();
		controller->setSendRedirect(false);
//		getchar();

		if (controller->getClientAgg().size() > 0) {
			Simulator::Schedule(Simulator::Now() + Seconds(0.25), ReSendRedirectAgg, controller);
		}
	}
}

int main (int argc, char *argv[])
{
  uint16_t seed = 0;

	string scenarioFiles = GetCurrentWorkingDir() + "/../content/scenario";
  double stopTime      = 600.0;
  string AdaptationLogicToUse = "dash::player::RateAndBufferBasedAdaptationLogic"; //dash::player::BufferBasedAdaptationLogic


	CommandLine cmd;
	//default parameters
  cmd.AddValue("stopTime", "The time when the clients will stop requesting segments", stopTime);
  cmd.AddValue("AdaptationLogicToUse", "Adaptation Logic to Use.", AdaptationLogicToUse);
  cmd.AddValue("seed", "Seed Experiment", seed);
	cmd.Parse (argc, argv);

	NetworkTopology network;
	ReadTopology(scenarioFiles + "/tree_l3_link_2", scenarioFiles + "/tree_l3_nodes", network);


	NodeContainer nodes;
	nodes.Create(network.getNodes().size());

	for (unsigned int i = 0; i < network.getNodes().size(); i += 1) {
		ostringstream ss;
		ss << network.getNodes().at(i)->getId();
		Names::Add(network.getNodes().at(i)->getType() + ss.str(), nodes.Get( network.getNodes().at(i)->getId() ));
	}

	// Later we add IP Addresses
	NS_LOG_INFO("Assign IP Addresses.");
	InternetStackHelper internet;

	fprintf(stderr, "Installing Internet Stack\n");
	// Now add ip/tcp stack to all nodes.
	internet.Install(nodes);

		// create p2p links
	vector<NetDeviceContainer> netDevices;
	Ipv4AddressHelper address;
	address.SetBase ("10.0.0.0", "255.255.255.0");
	PointToPointHelper p2p;

	for (unsigned int i = 0; i < network.getLinks().size(); i += 1) {
		p2p.SetDeviceAttribute("DataRate", DataRateValue( network.getLinks().at(i)->getRate() )); // Mbit/s

		// And then install devices and channels connecting our topology
		NetDeviceContainer deviceContainer;
		deviceContainer = p2p.Install(nodes.Get(network.getLinks().at(i)->getSrcId()), nodes.Get(network.getLinks().at(i)->getDstId()));

		address.Assign(deviceContainer);
		address.NewNetwork();
		netDevices.push_back(deviceContainer);
	}

	//Store IP adresses
	std::string addr_file = "addresses";
	ofstream out_addr_file(addr_file.c_str());
	for (unsigned int i = 0; i < nodes.GetN(); i++) {
		Ptr<Node> n = nodes.Get(i);
		Ptr<Ipv4> ipv4 = n->GetObject<Ipv4>();
		for (uint32_t l = 1; l < ipv4->GetNInterfaces(); l++) {
			out_addr_file << i <<  " " << ipv4->GetAddress(l, 0).GetLocal() << endl;
		}
	}
	out_addr_file.flush();
	out_addr_file.close();

	network.setNodeContainers (&nodes);

	// %%%%%%%%%%%% Set up the DASH server

	Ptr<Node> n_server = nodes.Get(7);
	Ptr<Ipv4> ipv4_server = n_server->GetObject<Ipv4> ();

	string str_ipv4_server = Ipv4AddressToString(ipv4_server->GetAddress(1,0).GetLocal());
	cout << "CDN Server = " << str_ipv4_server << endl;
	//=======================================================================================

	NS_LOG_INFO("Create Applications.");
	string representationStrings = GetCurrentWorkingDir() + "/../../dataset/netflix_vid1.csv";
	fprintf(stderr, "representations = %s\n", representationStrings.c_str ());

	DASHServerHelper server (Ipv4Address::GetAny (), 80, str_ipv4_server,
		                   "/content/mpds/", representationStrings, "/content/segments/");

	ApplicationContainer serverApps = server.Install(n_server);
	serverApps.Start (Seconds(0.0));
	serverApps.Stop (Seconds(stopTime));


	Ptr<DashController> controller = CreateObject<DashController> ();
	controller->SetNetworkTopology(&network);
	controller->setServerIp(str_ipv4_server);

	n_server->AddApplication(controller);
	controller->SetStartTime(Seconds(0.0));
	controller->SetStopTime(Seconds(stopTime));

	controller->addCdnServer(str_ipv4_server);

	// %%%%%%%%%%%% Set up the Mobility Position
	MobilityHelper mobility;
	// setup the grid itself: objects are laid out
	// started from (-100,-100) with 20 objects per row,
	// the x interval between each object is 5 meters
	// and the y interval between each object is 20 meters
	mobility.SetPositionAllocator("ns3::GridPositionAllocator",
		                          "MinX", DoubleValue (-10.0),
		                          "MinY", DoubleValue (-10.0),
		                          "DeltaX", DoubleValue (20.0),
		                          "DeltaY", DoubleValue (20.0),
		                          "GridWidth", UintegerValue (20),
		                          "LayoutType", StringValue ("RowFirst"));
	// each object will be attached a static position.
	// i.e., once set by the "position allocator", the
	// position will never change.
	mobility.SetMobilityModel ("ns3::ConstantPositionMobilityModel");

	YansWifiChannelHelper channel = YansWifiChannelHelper::Default();
  YansWifiPhyHelper 	  phy     = YansWifiPhyHelper::Default();


	// %%%%%%%%%%%% Set up the DASH clients and AP Positions

	unsigned n_ap = 0, n_clients = 5;
	NodeContainer clients;

	Ptr<ListPositionAllocator> positionAlloc = CreateObject <ListPositionAllocator>();

	for (unsigned int i = 0; i < network.getNodes().size(); i += 1) {
		Ptr<Node> node = nodes.Get(network.getNodes().at(i)->getId());

		size_t found = Names::FindName(node).find("ap");
		if (found != string::npos) {
			mobility.Install(node);

			Ptr<MobilityModel> mob = node->GetObject<MobilityModel>();

			int rng_client = 360/n_clients;
			double x = mob->GetPosition().x, y = mob->GetPosition().y;
			for (size_t i = 0; i < 360; i += rng_client) {
				double cosseno = cos(i);
				double seno    = sin(i);
				positionAlloc->Add(Vector(5*cosseno + x , 5*seno + y, 0));
			}

			NodeContainer c;
			c.Create(n_clients);
			clients.Add(c);

			internet.Install(c);

			WifiHelper wifi;
			WifiMacHelper mac;
	    phy.SetChannel(channel.Create());

			ostringstream ss;
			ss << "ns-3-ssid-" << ++n_ap;
	    Ssid ssid = Ssid(ss.str());

			wifi.SetRemoteStationManager("ns3::AarfWifiManager");
			wifi.SetStandard (WIFI_PHY_STANDARD_80211g);

			mac.SetType("ns3::ApWifiMac", "Ssid", SsidValue (ssid));
			NetDeviceContainer ap_dev =  wifi.Install(phy, mac, node);

			mac.SetType("ns3::StaWifiMac", "Ssid", SsidValue (ssid), "ActiveProbing", BooleanValue (false));
			NetDeviceContainer sta_dev = wifi.Install(phy, mac, c);

			address.Assign(ap_dev);
			address.Assign(sta_dev);
			address.NewNetwork();
		}
	}

	positionAlloc->Add(Vector(0, 0, 0));   // Ap 1
  positionAlloc->Add(Vector(30, 0, 0));  // Ap 2
  positionAlloc->Add(Vector(15, 15, 0)); // node2
  positionAlloc->Add(Vector(15, 30, 0)); // node3

	mobility.SetPositionAllocator(positionAlloc);
	mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
	mobility.Install(clients);

	mobility.Install(nodes.Get(1));
	mobility.Install(nodes.Get(2));
	mobility.Install(nodes.Get(0));
	mobility.Install(nodes.Get(7));

	// %%%%%%%%%%%% End Set up the Mobility Position

	controller->Setup(Ipv4Address::GetAny (), 1317);

	Ipv4GlobalRoutingHelper::PopulateRoutingTables();

	network.setClientContainers(&clients);

	// %%%%%%%%%%%% Set up the DASH Clients

	int dst_server = 7;
	unsigned rng_client = 0;
	double rdm 			= 0.0;

	SeedManager::SetRun(time(0));
	Ptr<UniformRandomVariable> uv = CreateObject<UniformRandomVariable> ();

	for (unsigned ap_i = 0; ap_i < network.getNodes().size(); ap_i += 1)
	{
		Ptr<Node> node = nodes.Get(network.getNodes().at(ap_i)->getId());
		size_t found = Names::FindName(node).find("ap");
		if (found != string::npos)
		{
			for (unsigned user = 0; user < n_clients; user++)
			{
				rdm += uv->GetValue();
				int UserId = user + rng_client * n_clients;

				int screenWidth = 1920;
				int screenHeight = 1080;

				stringstream mpd_baseurl;
				mpd_baseurl << "http://" << str_ipv4_server << "/content/mpds/";

				stringstream ssMPDURL;
				ssMPDURL << mpd_baseurl.str() << "vid" << 1 << ".mpd.gz";

				DASHHttpClientHelper player (ssMPDURL.str());
				player.SetAttribute("AdaptationLogic", StringValue(AdaptationLogicToUse));
				player.SetAttribute("StartUpDelay", StringValue("4"));
				player.SetAttribute("ScreenWidth", UintegerValue(screenWidth));
				player.SetAttribute("ScreenHeight", UintegerValue(screenHeight));
				player.SetAttribute("UserId", UintegerValue(UserId));
				player.SetAttribute("AllowDownscale", BooleanValue(true));
				player.SetAttribute("AllowUpscale", BooleanValue(true));
				player.SetAttribute("MaxBufferedSeconds", StringValue("60"));

				ApplicationContainer clientApps;
				clientApps = player.Install(clients.Get(UserId));
				clientApps.Start(Seconds(0.5 + rdm));
				clientApps.Stop(Seconds(stopTime));

				// Simulator::Schedule(Seconds(rdm + 0.35), Run, UserId, ap_i, dst_server, controller);
			}
			rng_client++;
		}
	}

	// %%%%%%%%%%%% sort out the simulation
	string dir = CreateDir("../bin-tree");
	AnimationInterface anim(dir + string("/topology.netanim"));

	stringstream gstream;
	gstream << dir << "/output-dash-" << seed << ".csv";
  DASHPlayerTracer::InstallAll(gstream.str());

	Simulator::Stop(Seconds(stopTime));
	Simulator::Run();
	Simulator::Destroy();

	DASHPlayerTracer::Destroy();

	return 0;
}
